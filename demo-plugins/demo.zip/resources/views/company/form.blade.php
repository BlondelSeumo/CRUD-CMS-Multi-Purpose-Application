@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'company?return='.$return, 'class'=>'form-vertical form-material validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 
			</div>
			<div class="col-md-6  text-right " >
				<div class="submitted-button">
					<button name="apply" class="tips btn btn-sm btn-primary  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
					<button name="save" class="tips btn btn-sm btn-success "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
					<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-warning  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>
				</div>	
			</div>
			
		</div>
	</div>	


	
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="">
			<div class="col-md-12">
						<fieldset><legend> company</legend>
				{!! Form::hidden('comp_id', $row['comp_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Contact Person  <span class="asterix"> * </span>  </label>									
										  <select name='contact_id' rows='5' id='contact_id' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Compapny Name  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='name' id='name' value='{{ $row['name'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Info / Description  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='info' id='info' value='{{ $row['info'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Logo    </label>									
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="logo" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="logo-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["logo"],"/uploads/images/sample/companies/") !!}
						</div>
					 						
									  </div> </fieldset></div>
	
		</div>
		
		<input type="hidden" name="action_task" value="save" />
		
		
				


	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#contact_id").jCombo("{!! url('company/comboselect?filter=contacts:contact_id:surname') !!}",
		{  selected_value : '{{ $row["contact_id"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("company/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop