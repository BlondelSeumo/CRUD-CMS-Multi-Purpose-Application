<div class="form-ajax-box">
{!! Form::open(array('url'=>'fullcrud?return='.$return, 'class'=>'form-horizontal form-material sximo-form validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'fullcrudFormAjax')) !!}

	<div class="toolbar-nav">	
		<div class="row">	
			<div class="col-sm-6 ">	
				<button type="submit" class="btn btn-sm  " name="apply">{{ Lang::get('core.sb_apply') }} </button>
				<button type="submit" class="btn btn-sm  " name="save">  {{ Lang::get('core.sb_save') }} </button>
			</div>	
			<div class="col-md-6 text-right">
				<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm  " title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>				
			</div>
					
		</div>
	</div>	
		<div class="card">
			<div class="card-body">

	
	<div class="col-md-12">
						<fieldset><legend> Full CRUD</legend>
				{!! Form::hidden('employeeNumber', $row['employeeNumber']) !!}					
									  <div class="form-group row  " >
										<label for="LastName" class=" control-label col-md-4 text-left"> LastName <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='lastName' id='lastName' value='{{ $row['lastName'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="FirstName" class=" control-label col-md-4 text-left"> FirstName </label>
										<div class="col-md-8">
										  <input  type='text' name='firstName' id='firstName' value='{{ $row['firstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Extension" class=" control-label col-md-4 text-left"> Extension </label>
										<div class="col-md-8">
										  <input  type='text' name='extension' id='extension' value='{{ $row['extension'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Email" class=" control-label col-md-4 text-left"> Email <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='email' id='email' value='{{ $row['email'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="ReportsTo" class=" control-label col-md-4 text-left"> ReportsTo </label>
										<div class="col-md-8">
										  <select name='reportsTo' rows='5' id='reportsTo' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="JobTitle" class=" control-label col-md-4 text-left"> JobTitle <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='jobTitle' id='jobTitle' value='{{ $row['jobTitle'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Photo" class=" control-label col-md-4 text-left"> Photo </label>
										<div class="col-md-8">
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="photo" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="photo-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["photo"],"/uploads/images/employees/") !!}
						</div>
					 
										 </div> 
										 
									  </div> </fieldset></div>									
						
	<input type="hidden" name="action_task" value="save" />

	</div>
	

</div>		
{!! Form::close() !!}
</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
</style>
@include('sximo.module.template.ajax.formjavascript')
<script type="text/javascript">
$(document).ready(function() { 
	 
	
	
		$("#reportsTo").jCombo("{!! url('fullcrud/comboselect?filter=employees:employeeNumber:lastName|lastName') !!}",
		{  selected_value : '{{ $row["reportsTo"] }}' });
		 	
	 
	
	var form = $('#fullcrudFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  function() {
				},
				success		:   function(data) {

					if(data.status == 'success')
					{
						ajaxViewClose('#{{ $pageModule }}');
						ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data');
						notyMessage(data.message);	
						$('#sximo-modal').modal('hide');	
					} else {
						notyMessageError(data.message);	
						return false;
					}	

				}  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

</script>		 