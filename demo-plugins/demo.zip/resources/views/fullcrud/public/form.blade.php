

		 {!! Form::open(array('url'=>'fullcrud/savepublic', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Full CRUD</legend>
				{!! Form::hidden('employeeNumber', $row['employeeNumber']) !!}					
									  <div class="form-group row  " >
										<label for="LastName" class=" control-label col-md-4 text-left"> LastName <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='lastName' id='lastName' value='{{ $row['lastName'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="FirstName" class=" control-label col-md-4 text-left"> FirstName </label>
										<div class="col-md-8">
										  <input  type='text' name='firstName' id='firstName' value='{{ $row['firstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Extension" class=" control-label col-md-4 text-left"> Extension </label>
										<div class="col-md-8">
										  <input  type='text' name='extension' id='extension' value='{{ $row['extension'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Email" class=" control-label col-md-4 text-left"> Email <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='email' id='email' value='{{ $row['email'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="ReportsTo" class=" control-label col-md-4 text-left"> ReportsTo </label>
										<div class="col-md-8">
										  <select name='reportsTo' rows='5' id='reportsTo' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="JobTitle" class=" control-label col-md-4 text-left"> JobTitle <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='jobTitle' id='jobTitle' value='{{ $row['jobTitle'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Photo" class=" control-label col-md-4 text-left"> Photo </label>
										<div class="col-md-8">
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="photo" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="photo-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["photo"],"/uploads/images/employees/") !!}
						</div>
					 
										 </div> 
										 
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#reportsTo").jCombo("{!! url('fullcrud/comboselect?filter=employees:employeeNumber:lastName|lastName') !!}",
		{  selected_value : '{{ $row["reportsTo"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
