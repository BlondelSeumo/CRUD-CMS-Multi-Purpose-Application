<div class="form-ajax-box p-4">
{!! Form::open(array('url'=>'sxpayment?return='.$return, 'class'=>'form-vertical validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'sxpaymentFormAjax')) !!}


				{!! Form::hidden('payment_id', $row['payment_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Invoice Number    </label>									
										  <select name='invoice_id' rows='5' id='invoice_id' class='select2 '   ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Payment Method    </label>									
										  <input  type='text' name='payment_method' id='payment_method' value='{{ $row['payment_method'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Payment Mode    </label>									
										  <input  type='text' name='payment_mode' id='payment_mode' value='{{ $row['payment_mode'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 				
									  <div class="row">

									  <div class="form-group col-md-4  " >
										<label for="ipt" class=" control-label "> Payment Date    </label>									
										  
				<div class="input-group input-group-sm m-b" style="width:150px !important;">
					{!! Form::text('payment_date', $row['payment_date'],array('class'=>'form-control form-control-sm date')) !!}
					<div class="input-group-append">
					 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
					 </div>
				</div> 						
									  </div> 					
									  <div class="form-group  col-md-5 " >
										<label for="ipt" class=" control-label "> Transaction ID Number    </label>									
										  <input  type='text' name='transaction_id' id='transaction_id' value='{{ $row['transaction_id'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									
									  <div class="form-group col-md-3 " >
										<label for="ipt" class=" control-label "> Amount    </label>									
										  <input  type='text' name='amount' id='amount' value='{{ $row['amount'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 		
									  </div>			
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Note    </label>									
										  <textarea name='note' rows='5' id='note' class='form-control form-control-sm '  
				           >{{ $row['note'] }}</textarea> 						
									  </div> 		

									   <div class="form-group  " >
									   		<button class="btn btn-sm btn-primary"> Save Change(s) </button>
									   </div>							
						
				


	
					{!! Form::close() !!}

</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
</style>
			 
<script type="text/javascript">
$(document).ready(function() { 
	
	
		$("#invoice_id").jCombo("{!! url('sxpayment/comboselect?filter=sx_invoices:invoice_id:number') !!}",
		{  selected_value : '{{ $row["invoice_id"] }}' });
		 	
	 	 
	
	$('.editor').summernote();
	
	$('.tips').tooltip();	
	$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
	$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 		
		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxpayment/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});
				
	var form = $('#sxpaymentFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  showRequest,
				success:       showResponse  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

function showRequest()
{
		
}  
function showResponse(data)  {		
	
	if(data.status == 'success')
	{
		ajaxViewClose('#{{ $pageModule }}');
		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data');
		notyMessage(data.message);	
		$('#sximo-modal').modal('hide');	
	} else {
		notyMessageError(data.message);	
		return false;
	}	
}			 

</script>		 