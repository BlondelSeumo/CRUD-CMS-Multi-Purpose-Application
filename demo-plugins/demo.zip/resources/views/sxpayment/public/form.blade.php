

		 {!! Form::open(array('url'=>'sxpayment/savepublic', 'class'=>'form-vertical','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> sxpayment</legend>
				{!! Form::hidden('payment_id', $row['payment_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Invoice Id    </label>									
										  <select name='invoice_id' rows='5' id='invoice_id' class='select2 '   ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Payment Method    </label>									
										  <input  type='text' name='payment_method' id='payment_method' value='{{ $row['payment_method'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Payment Mode    </label>									
										  <input  type='text' name='payment_mode' id='payment_mode' value='{{ $row['payment_mode'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Payment Date    </label>									
										  
				<div class="input-group input-group-sm m-b" style="width:150px !important;">
					{!! Form::text('payment_date', $row['payment_date'],array('class'=>'form-control form-control-sm date')) !!}
					<div class="input-group-append">
					 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
					 </div>
				</div> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Transaction ID Number    </label>									
										  <input  type='text' name='transaction_id' id='transaction_id' value='{{ $row['transaction_id'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Amount    </label>									
										  <input  type='text' name='amount' id='amount' value='{{ $row['amount'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Note    </label>									
										  <textarea name='note' rows='5' id='note' class='form-control form-control-sm '  
				           >{{ $row['note'] }}</textarea> 						
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#invoice_id").jCombo("{!! url('sxpayment/comboselect?filter=sx_invoices:invoice_id:number') !!}",
		{  selected_value : '{{ $row["invoice_id"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
