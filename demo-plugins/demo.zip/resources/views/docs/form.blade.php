
						
{!! Form::open(array('url'=>'docs?return='.$return, 'class'=>'form-vertical validated','files' => true )) !!}
{!! Form::hidden('doc_id', $row['doc_id']) !!}		
		@if($return !='section')			
			  <div class="form-group  " >
				<label for="ipt" class=" control-label "> Parent Articles  <span class="asterix"> * </span>  </label>		
				<select class="form-control form-control-sm" name='parent_id' id='parent_id'>
					<option value="{{ $parent }} "> No Parent </option>
					@foreach($parents as $par)
					<option value="{{ $par['rows']->doc_id }}" 
						@if( $par['rows']->doc_id == $row['parent_id'] ) selected @endif
						>{{ $par['rows']->title }}</option>
					@endforeach
				</select>				
			  </div> 		
		@endif					  			
					  <div class="form-group  " >
						<label for="ipt" class=" control-label "> Title  <span class="asterix"> * </span>  </label>									
						  <input  type='text' name='title' id='title' value='{{ $row['title'] }}'  required
		     class='form-control form-control-sm ' /> 						
					  </div> 					
					  <div class="form-group  " >
						<label for="ipt" class=" control-label "> Description  <span class="asterix"> * </span>  </label>									
						  <textarea name='description' rows='5' id='editor' required class='form-control form-control-sm editor '  
		 >{{ $row['description'] }}</textarea> 						
					  </div> 					
					  <div class="form-group  " >
						<label for="ipt" class=" control-label "> Status  <span class="asterix"> * </span>  </label>									
						  
	
	<input type='radio' name='status' value ='0' required  @if($row['status'] == '0') checked="checked" @endif class='minimal-green' > Disabled 
	
	<input type='radio' name='status' value ='1' required  @if($row['status'] == '1') checked="checked" @endif class='minimal-green' > Enabled  						
					  </div> 					
					  <div class="form-group  " >
						<label for="ipt" class=" control-label "> Order List  <span class="asterix"> * </span>  </label>									
						  <input  type='text' name='ordering' id='ordering' value='{{ $row['ordering'] }}' 
		     class='form-control form-control-sm ' /> 						
					  </div> 	

	@if($return =='section')
	<div class="form-group  " >
		<label for="ipt" class=" control-label "> Thumbnail  <span class="asterix"> * </span>  </label>									
						  
		<div class="fileUpload btn " > 
		    <span>  <i class="fa fa-camera"></i>  </span>
		    <div class="title"> Browse File </div>
		    <input type="file" name="thumbnail" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
		</div>
		<div class="thumbnail-preview preview-upload">
			{!! SiteHelpers::showUploadedFile( $row["thumbnail"],"/uploads/images/docs/") !!}
		</div>
	 						
					  </div> 
	@endif				  
	<input type="hidden" name="action_task" value="save" />
	<button type="submit" class="btn btn-primary"> Save Article </button>
	{!! Form::close() !!}
	
			
	
	
	<script src="{{ asset('sximo5/js/plugins/summernote/plugin')}}/summernote-ext-highlight.min.js"></script>	 
   <script type="text/javascript">
	$(document).ready(function() { 
		 $('.validated').parsley();
		$('.editor').summernote({ 
			height: 250 ,
	        toolbar: [
			 
			  ['font', ['bold', 'underline', 'clear']],
			  ['fontname', ['fontname']],
			  ['color', ['color']],
			  ['para', ['ul', 'ol', 'paragraph']],
			  ['table', ['table']],
			  ['insert', ['link', 'picture', 'video']],
			  ['view', ['fullscreen', 'codeview', 'help']],
			  ['highlight', ['highlight']]
			],
		});	
		$('.upload').change(function() {

			var id = $(this).attr('name');

			var files = $(this).prop('files');
			$(this).parent().closest('.title').html(files[0].name)
			console.log(files[0].name)
			const fr = new FileReader()
			fr.readAsDataURL(files[0])
			fr.addEventListener('load', () => {
			 	$('.'+id+'-preview').html('<img src="'+fr.result+'" width="120" />')
			})  		
		  	
		})		
		$('input[type="checkbox"].minimal-green, input[type="radio"].minimal-green').iCheck({
	      checkboxClass: 'icheckbox_flat-blue',
	      radioClass: 'iradio_flat-blue'
	    }); 
	});
	
	</script>		 
