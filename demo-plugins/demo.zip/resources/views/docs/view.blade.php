@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $data['title']  }} </h2></div>
<div class="toolbar-nav" >   
	<div class="row">
		<div class="col-md-6">
			<a href="{{ url('docs') }}" class="btn  btn-sm" ><i class=" fa fa-times "></i> </a>
		</div>
		<div class="col-md-6 text-right"> 	
			@if($access['is_add'] ==1)
			<a href="{{ url('docs/create?return='.$data['alias'].'&parent='.$data['doc_id']) }}" onclick="SximoModal(this.href,' New Article'); return false" class="btn  btn-sm"  
				title="{{ __('core.btn_create') }}"><i class=" fa fa-plus "></i> New Article </a>
			@endif
			@if($access['is_edit'] ==1)
			<a href="{{ url('docs/'.$row['doc_id'].'/edit?return='.$data['alias'].'&parent='.$data['doc_id']) }}" onclick="SximoModal(this.href,' Edit Article'); return false" class="btn  btn-sm" ><i class=" fa fa-pencil "></i> Edit </a>
			@endif
			@if($access['is_remove'] ==1)
			<a href="{{ url('docs/delete?id='.$row['doc_id'].'&return='.$data['alias'] ) }}" onclick="SximoConfirmDelete(this.href); return false" class="btn  btn-sm" ><i class=" fa fa-trash-o "></i> Delete </a>
			@endif

		</div>
	</div>
</div>			
<div class="card" >
	<div class="docs-menu bg-white">
		<div class="input-group mb-3 p-3 docs-search">			 
		  <input type="text" class="form-control onsearch" data-target="{{ url($pageModule) }}"  placeholder=" Type And Hit Enter ">
		   
		</div>
		<div class="p-3">
		<ul>
			<li> <a href="{{ url('docs/'.$data['alias']) }}"> Home </a> </li>
		@foreach($articles as $menu)
			<li> <a href="{{ url('docs/'.$data['alias'].'?article='.$menu['rows']->doc_id) }}"> {{ $menu['rows']->title }} </a> </li>
			@if(count($menu['childs']) >=1 ) 
				<ul>
					@foreach($menu['childs'] as $child)
						<li> <a href="{{ url('docs/'.$data['alias'].'?article='.$child->doc_id) }}"> 
							<i class="lni-book"></i> 
							{{ $child->title }} </a> </li>
					@endforeach

				</ul>
			@endif
		@endforeach
		</ul>
		</div>

	</div>

	<div class="docs-content">
		<div class="">

			<fieldset class="mode" id="view-article">
	
					<legend> {{ $row['title']  }} </legend>
					<div>
						{!! $row['description'] !!}
					</div>
				
			</fieldset>	

				
			
		</div>	

	</div>

</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('.mode').hide();
		$('#view-article').show()

	})
</script>

<style type="text/css">
	.table-container {
		padding: 0 ;
	}
	.docs-menu {
		height: calc(100vh - 100px);
		overflow: auto;
		float: left;
		width: 250px;
		position: absolute;
	}
	.docs-menu .docs-search {
		background: #f9f9fe;
	}
	.docs-menu ul{
		margin: 0;
		padding:0;
		list-style: none;
	}
	.docs-menu ul li a{
		text-transform: uppercase;
		line-height: 28px;
		font-size: 12px;
		color : #3a3a3a;
		font-weight: 500;
		display: block;
	}
	.docs-menu ul  ul{
		
	}
	.docs-menu ul  ul li a{
		text-transform: none !important;
		line-height: 28px;
		font-weight: 400;
	}
	.docs-menu ul  ul li a i{
		margin-right: 10px;
	}
	.docs-content {
		padding: 20px 20px 0 280px;
		
		height: calc(100vh - 100px);
		overflow: auto;
	}
	.table-container {
		height: calc(100vh - 80px);
	}
</style>
@stop
