<div class="list-group">
	@foreach ($rowData as $row)
		<li class="list-group-item list-group-item-action " style="min-height: 120px;">
			<div style="width: 80px; float: left; margin-right: 100px; position: absolute; min-height: 80px"> 
			@if(file_exists('uploads/images/docs/'.$row['row']->thumbnail) && $row['row']->thumbnail != NULL )
			<img src="{{ asset('uploads/images/docs/'.$row['row']->thumbnail)}}" class="avatar" width="60" alt="...">
			@else 
			<img src="{{ asset('uploads/images/docs/default.png')}}" class="avatar" width="60" alt="...">
			@endif
		</div>
			<div class="d-flex w-100 justify-content-between " style="padding-left: 80px;">
		      <h3 class="mb-1">
		      	<a href="{{ url(Request::segment(1).'?a='. $row['row']->alias ) }}"> {{ $row['row']->title }} </a> </h3>

		      <small>3 days ago</small>
		    </div>
		    <div class="mb-1 " style="padding-left: 100px">
		    	{!! substr($row['row']->description,0,255) !!} ...
		    	
		    </div>
		  

		
		</li>
	@endforeach	

</div>