
<div class="text-center docs-header" >
	<div class="container">
		<h3> FAQ :  {{ $data['title'] }} </h3>
		
		
	</div>	
</div>
<div class="container " >
	<ul class="faq">
	@foreach($articles as $menu)
		<li>
			  <h3>{{ $menu['rows']->title }}</h3> 
			 <ul>
			 	@foreach($menu['childs'] as $child)								
					<li>
						<a href="javascript:;" class="link-item" code="#faq-{{ $child->doc_id }}"> {{ $child->title }} </a>
						<div id="faq-{{ $child->doc_id }}" >
							{!! $child->description !!} 
						</div>

					</li>
					<!--
					
					-->					
				@endforeach
			</ul>	
		</li>
	@endforeach
	</ul>
	

</div>
<script type="text/javascript">
	$(document).ready(function() {
		
		$('ul.faq li li a').click(function() {
			
			var code = $(this).attr('code')
			$('ul.faq li li div').hide()
			$(code).show('slow')
			
		});
		
	})
</script>

<style type="text/css">
	.docs-header {
		background-image: linear-gradient(0deg,#fff,#f1f1f1);
		padding: 20px;
	}
	.docs-header h3 {
		text-transform: uppercase;
		font-size: 16px;
	}

	ul.faq {
		list-style: none;
		margin: 0;
		padding: 0;
	} 
	ul.faq li{
		line-height: 40px;
		margin-bottom: 20px;
	}
	ul.faq li a{
		color: #434343;
		font-weight: 400;
	}
	ul.faq li  li::before{
		display: block;
	    content: '';
	    position: absolute;
	    width: 0;
	    height: 0;
	   margin-top: 15px;
	    border-top: 6px solid transparent;
	    border-left: 8px solid #ff9900;
	    border-bottom: 6px solid transparent;
	}
	ul.faq li ul {
		list-style: none;
		margin: 0;
		padding: 0;
	}
	ul.faq li ul li a{
			font-weight: 500;
			margin-left: 20px;

	}
	ul.faq li ul li div{
		display: none;
		padding-left: 20px;
	}
</style>
