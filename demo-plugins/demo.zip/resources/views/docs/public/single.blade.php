
<div class="text-center docs-header" >
	<div class="container">
		<h3> Documentation :  {{ $data['title'] }} </h3>
		
		
	</div>	
</div>
<div class="container " >
	<div class="row">
		<div class="col-md-3">
			<div class="docs-menu ">
				
				<ul>
				@foreach($articles as $menu)
					<li> <a href="{{ url( Request::segment(1).'?article='.$menu['rows']->doc_id) }}"> {{ $menu['rows']->title }} </a> </li>
					@if(count($menu['childs']) >=1 ) 
						<ul>
							@foreach($menu['childs'] as $child)
								<li> <a href="{{ url( Request::segment(1).'?article='.$child->doc_id) }}"> 
									
									{{ $child->title }} </a> </li>
							@endforeach

						</ul>
					@endif
				@endforeach
				</ul>
				

			</div>
		</div>
		<div class="col-md-9">

			<div class="docs-content">
				<div class="">

					<fieldset class="mode" id="view-article">
			
							<legend> {{ $row['title']  }} </legend>
							<div>
								{!! $row['description'] !!}
							</div>
						
					</fieldset>	

					</div>
				</div>	

			</div>
		</div>
	</div>		

</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('.mode').hide();
		$('#view-article').show()

	})
</script>

<style type="text/css">
	.docs-header {
		background-image: linear-gradient(0deg,#fff,#f1f1f1);
		padding: 30px;
	}
	.docs-header h3 {
		text-transform: uppercase;
		font-size: 16px;
	}
	.docs-menu {
		
		border-right: solid 1px #eee;
		padding-top: 20px;
	}
	.docs-menu ul{
		margin: 0;
		padding:0;
		list-style: none;
	}
	.docs-menu ul li a{
		
		line-height: 40px;

		font-weight: 500;
		display: block;
	}
	.docs-search {
		border-bottom: solid 1px #ddd;

	}
	.docs-search input {
		border :none !important;
		font-size: 12px;
		border-radius: 0 !important;
	}
	.docs-menu ul  li ul {
		margin: 0; 
		padding: 0;
	}
	.docs-menu ul ul li::before {

	    display: block;
	    content: '';
	    position: absolute;
	    width: 0;
	    height: 0;
	    margin-top:15px;
	    border-top: 6px solid transparent;
	    border-left: 8px solid #ff9900;
	    border-bottom: 6px solid transparent;		
	}
	.docs-menu ul  ul li a{
		text-transform: none !important;
		line-height: 40px;
		font-weight: 300;
		padding-left: 20px;
		color: #4b4b4b;
		font-size: 13px;
	}
	.docs-menu ul  ul li a i{
		margin-right: 10px;
	}
	.docs-content {
		padding-top: 20px;
	}
	.table-container {
		height: calc(100vh - 80px);
	}
</style>
