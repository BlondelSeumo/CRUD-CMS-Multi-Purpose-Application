<div class="text-center docs-header" >
	<div class="container">
		<h1> {{ $data['title'] }} </h1>
		<div class="box-search pb-3 pt-3">
			<input type="text" placeholder="Enter a question or topic " class="form-control " />
		</div>
		
		
	</div>	
</div>
<div class="container " >
	<div class="knowledgebase-sximo">
		@if( $mode=='default')
		<div class="row ">
			@foreach($articles as $menu)
			<div class="col-md-6 ">
		  		<div class="box ">
		  			<h3>
		  				<a href=""> 
		  					<span class="iconic">
		  						<i class="fa fa-question"></i>
		  					</span>	


		  					{{ $menu['rows']->title }} 
		  				</a>	
		  			</h3>
		  			
			  			<ul>
			  			@foreach($menu['childs'] as $child)								
							<li><a href="{{ url(Request::segment(1).'?article='.$child->doc_id)}}"> <span> {{ $child->title }} </span> </a> </li>
						@endforeach
						</ul>
					
		  		</div>
		  	</div>
		  	@endforeach
		</div>
		@else 
		<div class="detail">
			<ol class="breadcrumb">
				<li> <a href="{{ url( Request::segment(1)) }}"> Home  </a></li>
				<li> / </li>
				<li> <a href=""> Basic Skill </a></li>
			</ol>

			<div class="row">
				<div class="col-md-8">
					<h2> {{ $row['title']}} </h2>
					<div>
						{!! $row['description'] !!}
					</div>
				
					
					<div class="pt-3">
						<p><b>Was this article helpful ?</b> </p>
						<button type="button" class="btn btn-sm btn-success"><i class="fa fa-thumbs-up"></i> 156 </button>
						<button type="button" class="btn btn-sm btn-warning"> <i class="fa fa-thumbs-down"></i> 12</button>


					</div>
				</div>
				<div class="col-md-4 relateds">	
					<h3> Related Article(s) </h3>
					<div class="box">
					<ul style="margin: 0 !important; padding: 0 !important">
			  			@foreach($related as $rl)								
							<li><a href="{{ url(Request::segment(1).'?article='.$rl['rows']->doc_id )}}"> <span> {{ $rl['rows']->title }} </span> </a> </li>
						@endforeach
						</ul>
					</div>	
				</div>
			</div>		
		</div>	
		@endif;
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		
		
	})
</script>

<style type="text/css">
	.docs-header {
		background-image: linear-gradient(0deg,#fff,#f9f9f9);
		padding: 30px;
	}
	.docs-header h3 {
		text-transform: uppercase;
		font-size: 16px;
	}
	.knowledgebase-sximo {


	}
	.knowledgebase-sximo h3{
		font-size: 18px;
		line-height: 40px;
	}
	.knowledgebase-sximo h3 span{
		font-size: 18px;
		width: 60px;
		height: 60px;
		line-height: 60px;
		float: left;
		display: inline-block;
		vertical-align: middle;
		text-align: center;
		background: #f5f5f5;
		border-radius: 50%;
		margin: -8px 20px 0 0;
		color : #888;
	}
	.knowledgebase-sximo h3  a{
		color : #888;
	}
	.knowledgebase-sximo h3 span i{
		font-size: 24px;
		
	}
	.knowledgebase-sximo .box{
		margin: 0 0 40px 0;

	}
	.knowledgebase-sximo .box ul{
		padding-left: 70px;
		list-style: none;
		margin: 0;

	}
	.knowledgebase-sximo .box ul{
		padding-left: 70px;
	}
	.knowledgebase-sximo .box ul li a{
		color : #4b4b4b;
		line-height: 30px;
		

	}
	.knowledgebase-sximo .box ul li span {
		padding-left: 20px;

	}
	.knowledgebase-sximo .box ul li::before {
		display: block;
	    content: '';
	    position: absolute;
	    width: 0;
	    height: 0;
	    margin-top: 10px;

	    border-top: 6px solid transparent;
	    border-left: 8px solid #ff9900;
	    border-bottom: 6px solid transparent;
	}
	ol.breadcrumb {
		margin-bottom: 40px; 
		border-bottom: solid 1px #eee;
	}
	ol.breadcrumb  li{
		padding-right: 10px;
		font-size: 16px;
	}
	ol.breadcrumb  li a{
		color: #222;
		font-weight: 500;
	}


</style>
