@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>
<div class="toolbar-nav" >   


	<div class="row">
		<div class="col-md-6 text-right">
			<div class="input-group text-right pull-right">
			     
			      <input type="text" class="form-control form-control-sm onsearch" data-target="{{ url($pageModule) }}" aria-label="..." placeholder=" Type And Hit Enter ">
			    </div>
		</div>  

		<div class="col-md-6 text-right"> 	
			

			<div class="btn-group">
				<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bars"></i> Bulk Action </button>
		        <ul class="dropdown-menu">
		        @if($access['is_remove'] ==1)
					 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="{{ __('core.btn_remove') }}">
					Remove Selected </a></li>
				@endif 
				@if($access['is_add'] ==1)
					<li class="nav-item"><a href="javascript://ajax" class=" copy nav-link " title="Copy" > Copy selected</a></li>
					<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule .'/import?return='.$return) }}" onclick="SximoModal(this.href, 'Import CSV'); return false;" class="nav-link "> Import CSV</a></li>

					
				@endif
				<div class="dropdown-divider"></div>
		        @if($access['is_excel'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=excel&return='.$return) }}" class="nav-link "> Export Excel </a></li>	
				@endif
				@if($access['is_csv'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=csv&return='.$return) }}" class="nav-link "> Export CSV </a></li>	
				@endif
				@if($access['is_pdf'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=pdf&return='.$return) }}" class="nav-link "> Export PDF </a></li>	
				@endif
				@if($access['is_print'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=print&return='.$return) }}" class="nav-link "> Print Document </a></li>	
				@endif
				<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule) }}"  class="nav-link "> Clear Search </a></li>
		          	
		        
		          
		        </ul>
		    </div> 

		    @if($access['is_add'] ==1)
			<a href="{{ url('docs/create?return=section') }}" onclick="SximoModal(this.href,' New Documentation'); return false" class="btn btn-primary btn-sm"  
				title="{{ __('core.btn_create') }}"><i class=" fa fa-plus "></i> Create New </a>
			@endif

		</div>
  
	</div>	

</div>	
<div class="table-container">
	<div class="card">


			<div class="list-group">
				@foreach ($rowData as $row)
					<li class="list-group-item list-group-item-action " style="min-height: 120px;">
						<div style="width: 100px; float: left; margin-right: 120px; position: absolute; min-height: 120px"> 
						@if(file_exists('uploads/images/docs/'.$row['row']->thumbnail) && $row['row']->thumbnail != NULL )
						<img src="{{ asset('uploads/images/docs/'.$row['row']->thumbnail)}}" class="avatar" width="80" alt="...">
						
						@endif
					</div>
						<div class="d-flex w-100 justify-content-between " style="padding-left: 120px;">
					      <h5 class="mb-1">
					      	<a href="{{ url('docs/'. $row['row']->alias ) }}"> {{ $row['row']->title }} </a> </h5>

					      <small>
					      	@if($access['is_edit'] ==1)
					      	<a href="{{ url('docs/'.$row['row']->doc_id.'/edit?return=section') }}" onclick="SximoModal(this.href,' Edit Documentation'); return false" class="btn btn-default btn-sm"  title="{{ __('core.btn_create') }}"><i class=" fa fa-pencil "></i></a>
					      	@endif
					      	@if($access['is_remove'] ==1)
					      	<a href="{{ url('docs/delete?id='.$row['row']->doc_id.'&return=') }}" onclick="SximoConfirmDelete(this.href); return false" class="btn btn-default btn-sm"  title="{{ __('core.btn_delete') }}"><i class=" fa fa-trash-o "></i></a>
					      	@endif
					      </small>
					    </div>
					    <div class="mb-1 " style="padding-left: 120px">
					    	{!! $row['row']->description !!}
					    	<br />
					    	<b> ShortCode </b> : [sc:My fnc=documentation|id={{ $row['row']->doc_id }}] [/sc] 
					    </div>
					  

					
					</li>
				@endforeach	

			</div>
		

	</div>
</div>
			
</div>

<script>
$(document).ready(function(){
	$('.copy').click(function() {
		var total = $('input[class="ids"]:checkbox:checked').length;
		if(confirm('are u sure Copy selected rows ?'))
		{
			$('input[name="action_task"]').val('copy');
			$('#SximoTable').submit();// do the rest here	
		}
	})	
	
});	
</script>	
<style type="text/css">
	.kb-lists {
		height: 200px;
		overflow: hidden;
	}
	.kb-lists ul {
		margin: 0; 
		padding: 0 ;
		list-style: none ;
	}
	.kb-lists ul li a{
		font-size: 14px;
	}
</style>	
@stop
