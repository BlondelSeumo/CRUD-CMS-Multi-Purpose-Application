<ul class="checklist-todo">
	@foreach($todo as $td)
	<li class="checklist-todo-item @if($td->status ==1) done @endif"><input class="minimal-green " value="{{ $td->todo_id }}" name="check-item" type="checkbox" 
		@if($td->status ==1) checked="true" @endif

		/><span > {{ $td->todo_name}}  </span>
		@if(Session('uid') == $td->user_id)
		<button class="btn btn-xs text-danger pull-right" onclick="deleteItems('todo','<?php echo $td->todo_id;?>');" style=""><i class="fa fa-times"></i></button>
		@endif
	</li>

	@endforeach
</ul>

<script type="text/javascript">
	$(document).ready(function() { 
		$('input[type="checkbox"].minimal-green, input[type="radio"].minimal-green').iCheck({
	      checkboxClass: 'icheckbox_flat-blue',
	      radioClass: 'iradio_flat-blue'
	    }); 
	    $('.minimal-green').on('ifChanged', function(event) {
	    	if( event.target.checked == true) {
	    		$(this).closest('li').addClass('done')
	    		$.get( '<?php echo url('sxtask/todo_ok?id=');?>' + event.target.value ,function( data ) {
					
					
				});
	    	} else {
	    		$(this).closest('li').removeClass('done')
	    		$.get( '<?php echo url('sxtask/todo_cancel?id=');?>' + event.target.value ,function( data ) {					
					
				});
	    	}
		  //  alert('checked = ' + event.target.checked);
		   // alert('value = ' + event.target.value);
		});
	});
      
</script>	