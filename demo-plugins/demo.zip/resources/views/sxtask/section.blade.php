<div class="p-5">
{!! Form::open(array('url'=>'sxtask?return='.$return, 'class'=>'form-horizontal validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'sxtaskSectionAjax')) !!}
	
	@if( $filter == 0 || $filter =='')
	<div class="form-group   " >
		<label  class=" control-label "> Section Name </label>		
		 <select name="project_id" class="form-control form-control-sm">
		 	@foreach($projects as $project)
		 	<option value="{{ $project->project_name }}" @if($project->project_id == $filter ) selected @endif >{{ $project->project_name }}</option>
		 	@endforeach
		 </select>
		 
	</div>
	@else 
	 <input type="hidden" name="project_id" value="{{ $filter }}" />

	@endif

	<div class="form-group   " >
		<label  class=" control-label "> Section Name </label>
		
		  <input  type='text' name='section_name' id='section_name' value="{{ $row['section_name'] }}" class='form-control form-control-sm ' /> 
		 
	</div>		
	<div class="form-group   " >
		<button type="submit" name="submit" class="btn btn-sm btn-primary "> Save Section </button> 
		 <input type="hidden" name="action_task" value="section" />
		 <input type="hidden" name="section_id" value="{{ $row['section_id'] }}" />
		 
	</div>	 
	
{!! Form::close() !!}
</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
</style>
			 
<script type="text/javascript">
$(document).ready(function() { 
	 
	
	$('.editor').summernote();
	
	$('.tips').tooltip();	
	$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
	$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 		
		
	var form = $('#sxtaskSectionAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  showRequest,
				success:       showResponse  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

function showRequest()
{
		
}  
function showResponse(data)  {		
	
	if(data.status == 'success')
	{
		ajaxViewClose('#{{ $pageModule }}');
		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data?p=<?php echo $filter;?>');
		notyMessage(data.message);	
		$('#sximo-modal').modal('hide');	
	} else {
		notyMessageError(data.message);	
		return false;
	}	
}			 

</script>		 