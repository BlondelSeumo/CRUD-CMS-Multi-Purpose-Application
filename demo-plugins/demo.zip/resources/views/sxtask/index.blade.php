@extends('layouts.app')

@section('content')


<div class="resultData"></div>
<div id="{{ $pageModule }}View"></div>			
<div id="{{ $pageModule }}Grid"></div>
	

<script>
$(document).ready(function(){
	reloadData('#{{ $pageModule }}','{{ $pageModule }}/data?p=<?php echo $project;?>&view=<?php echo $view_type;?>');	
});	
function refreshData() {
	reloadData('#{{ $pageModule }}','{{ $pageModule }}/data?p=<?php echo $project;?>&view=<?php echo $view_type;?>');		
}
function viewType( type) {
	reloadData('#{{ $pageModule }}','{{ $pageModule }}/data?p=<?php echo $project;?>&view=' + type);	
}
</script>	
@endsection