<div class="page-header"><h2> {{ $pageTitle }}  </h2></div>

<div class="toolbar-nav">
	<div class="row">
		<div class="col-md-6">			
			<div class="input-group ">
		      <div class="input-group-prepend">
		      	 <a href="javascript://ajax" class="btn btn-default btn-sm " onclick="refreshData()"> <i class="fa fa-refresh"></i></a>
		      	<a href="javascript:;" class="btn btn-sm btn-default" onclick="viewType('list');" ><i class="fa fa-table"></i></a>

		      	<a href="javascript:;" onclick="viewType('kanban');" class="btn btn-sm btn-default"><i class="fa fa-reorder"></i></a>
		      	<a href="javascript:;" onclick="viewType('calendar');" class="btn btn-sm btn-default"><i class="fa fa-calendar"></i></a>
		        <button type="button" class="btn btn-default btn-sm " style="text-transform: none !important" ><i class="fa fa-reload"></i> Switch to Project </button>
		      </div><!-- /btn-group -->
		      <select class="form-control form-control-sm" onchange="switchProject(this.value)">
		      		<option value="0">All Projects </option>
		      		@foreach($projects as $pro)
		      		<option value="{{ $pro->project_id }}" @if($filter== $pro->project_id) selected @endif >{{ $pro->project_name }} </option>
		      		@endforeach
		      	</select>	

		    </div>
		</div>

		<div class="col-md-6 text-right pull-right">	
			@if($access['is_add'] ==1)
			
				<a href="{{ url('sxtask/section?p='.$filter.'&return='.$return) }}" class="btn    btn-sm"  onclick="SximoModal(this.href ,'New Section'); return false ;" 
				title="New Section"><i class=" fa fa-plus "></i>  Section / Milestone </a>

			@endif

			<div class="btn-group">
				<button type="button" class="btn btn-sm   dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bars"></i> Bulk Action </button>
		        <ul class="dropdown-menu">
		        @if($access['is_remove'] ==1)
					 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="{{ __('core.btn_remove') }}">
					Remove Selected </a></li>
				@endif 
				@if($access['is_add'] ==1)
					<li class="nav-item"><a href="javascript://ajax" class=" copy nav-link " title="Copy" > Copy selected</a></li>
					<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule .'/import?return='.$return) }}" onclick="SximoModal(this.href, 'Import CSV'); return false;" class="nav-link "> Import CSV</a></li>

					
				@endif
				<div class="dropdown-divider"></div>
		        @if($access['is_excel'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=excel&return='.$return) }}" class="nav-link "> Export Excel </a></li>	
				@endif
				@if($access['is_csv'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=csv&return='.$return) }}" class="nav-link "> Export CSV </a></li>	
				@endif
				@if($access['is_pdf'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=pdf&return='.$return) }}" class="nav-link "> Export PDF </a></li>	
				@endif
				@if($access['is_print'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=print&return='.$return) }}" class="nav-link "> Print Document </a></li>	
				@endif
				<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule) }}"  class="nav-link "> Clear Search </a></li>
		          	
		        
		          
		        </ul>
		    </div>   

		</div>
	</div>
</div>		
<div class="">
			<!-- Table Grid -->
			
 			{!! Form::open(array('url'=>'sxtask?'.$return, 'class'=>'form-horizontal m-t' ,'id' =>'SximoTable' )) !!}
 		@if( $view_type  =='kanban')
 			@include('sxtask.kanban')

 		@elseif( $view_type  =='calendar')
 			@include('sxtask.calendar')	

 		@else
 			<div class="card">

			<table class="table">
	
				<tbody>
					@foreach ($tasks as $row)
					<tr>
						
						<td colspan="5" style="background-color: #f9f9fe; font-size: 14px; cursor: pointer;"  onclick="SximoModal('{{ url('sxtask/section?id='.$row['section']->section_id) }}', '{{ $row['section']->section_name }}'); return false ; ">
							
						 <b> {{ $row['section']->section_name }} </b>   <small>( {{ $row['section']->project_name }} )</small></td>
						 <td colspan="2" class="text-right"  style="background-color: #f9f9fe;">
						 	<a href="{{ url('sxtask/create?p='.$row['section']->project_id.'&section_id='.$row['section']->section_id) }}" class="btn  btn-xs"  
							title="{{ __('core.btn_create') }}" onclick="SximoModal(this.href); return false ;"><i class=" fa fa-plus "></i> New Task </a>

							<a href="{{ url('sxtask?p='.$filter.'&id='.$row['section']->section_id) }}" class="btn  btn-xs tips"  
							title="{{ __('core.btn_remove') }}" onclick="SximoConfirmDeleteSection(this.href); return false ;"><i class=" fa fa-trash-o "></i> </a>
						 </td>
					</tr>
						@foreach ($row['tasks'] as $task)
						<tr>
							<td> <input type="checkbox" class="ids minimal-green" name="ids[]" value="<?php echo $task->task_id ;?>" /></td>
							<td width="50%" style="width: 50%; cursor: pointer;" onclick="SximoModal('{{ url('sxtask/'.$task->task_id.'?p='.$row['section']->project_id) }}', '{{ $task->task_name }}'); return false ; ">
							<i class="fa fa-ellipsis-v" style="margin-right:10px; "></i>
							 {{ $task->task_name }}</td>
							<td width="150" style="width: 150px"><small> {{ number_format($task->progress,0) }} % </small>

									<div class="progress progress-sm">
									  <div class="progress-bar bg-success" role="progressbar" style="width: {{ $task->progress }}%" aria-valuenow="{{ $task->progress }}" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
							</td>
							<td><badge class="badge badge-primary"> {{ $task->todo }} / {{ $task->finished }} </badge></td>
							<td class="{{ $task->task_status }}">{{ str_replace("_"," ",ucwords($task->task_status)) }}</td>
							<td> {{ date("d M", strtotime( $task->start_date)) }}</td>
							<td> 
								<img src="{{ asset('uploads/users/'.$task->avatar) }}" width="30" class="avatar" style="margin-right: 10px;" /> 	
								<small>{{ $task->fullname }}</small></td>
							
							
						</tr>
						@endforeach

					@endforeach
				</tbody>
			</table>
		   
			<input type="hidden" name="action_task" value="" />
		</div>	
		@endif	
	{!! Form::close() !!}
	</div>
@include('sximo.module.template.ajax.javascript') 	
	<script type="text/javascript">
		function switchProject(id) {
			window.location.href="<?php echo url('sxtask?p=');?>"+ id
		}

		function SximoConfirmDeleteSection( url )
		{

			Swal.fire({
		        title: 'Confirm ?',
		        text: ' Are u sure deleting this section with all tasks inside ? ',
		        type: 'warning',
		        showCancelButton: true,
		        confirmButtonText: 'Yes, please',
		        cancelButtonText: 'cancel'
		      }).then((result) => {
		        if (result.value) {
		         	$.post( url ,{ action_task : 'delete_section'} , function( data) {
		         		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data?p=<?php echo $filter;?>');
		         	})
		        }
		      })

			return false;
		}
	</script>
	<style type="text/css">
	.kanban-view {
		height: calc(100vh - 160px) ;
		background-color: #ececec;
		display: flex;
		overflow-x: auto;
		
		width: auto;
	}
	.kanban-view .block{
		width: 250px !important; 
		float: left;
		margin-right: 10px;
		background-color: #fff;
	}
	.kanban-view .block .title{
		line-height: 30px;
		background-color: #f9f9f9;
		font-weight: 700;
		text-align: center;
	}
	.kanban-view .block .task-list {
		padding: 20px 10px;
	}
	.kanban-view .block .task-list ul{
		padding: 0px;
		margin: 0;
		list-style: none;
	}
	.kanban-view .block .task-list ul li{
		line-height: 30px; 
		padding-left: 20px;
		border:solid 1px #eee;
		margin-bottom: 20px;
	}
	.progress {
		height: 10px;
	}
	td.not_started , 
	tr td.not_started:hover {
		border-left: solid 5px #eee ;
	}
	td.in_progress {
	
		border-left: solid 5px blue ;
		color : blue;
		
	}
	td.review {
	
		border-left: solid 5px orange ;
		color : orange;
	}
	td.completed {
		
		border-left: solid 5px green ;
		color : green;
	
	}





</style>	