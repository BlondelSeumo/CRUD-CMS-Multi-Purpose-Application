<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Task Id', (isset($fields['task_id']['language'])? $fields['task_id']['language'] : array())) }}</td>
						<td>{{ $row->task_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Project Id', (isset($fields['project_id']['language'])? $fields['project_id']['language'] : array())) }}</td>
						<td>{{ $row->project_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Section Id', (isset($fields['section_id']['language'])? $fields['section_id']['language'] : array())) }}</td>
						<td>{{ $row->section_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Milestone Id', (isset($fields['milestone_id']['language'])? $fields['milestone_id']['language'] : array())) }}</td>
						<td>{{ $row->milestone_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Task Name', (isset($fields['task_name']['language'])? $fields['task_name']['language'] : array())) }}</td>
						<td>{{ $row->task_name}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Task Desc', (isset($fields['task_desc']['language'])? $fields['task_desc']['language'] : array())) }}</td>
						<td>{{ $row->task_desc}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Task Status', (isset($fields['task_status']['language'])? $fields['task_status']['language'] : array())) }}</td>
						<td>{{ $row->task_status}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Task Priority', (isset($fields['task_priority']['language'])? $fields['task_priority']['language'] : array())) }}</td>
						<td>{{ $row->task_priority}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Assigned To', (isset($fields['assigned_to']['language'])? $fields['assigned_to']['language'] : array())) }}</td>
						<td>{{ $row->assigned_to}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Start Date', (isset($fields['start_date']['language'])? $fields['start_date']['language'] : array())) }}</td>
						<td>{{ $row->start_date}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('End Date', (isset($fields['end_date']['language'])? $fields['end_date']['language'] : array())) }}</td>
						<td>{{ $row->end_date}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Created By', (isset($fields['created_by']['language'])? $fields['created_by']['language'] : array())) }}</td>
						<td>{{ $row->created_by}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Followers', (isset($fields['followers']['language'])? $fields['followers']['language'] : array())) }}</td>
						<td>{{ $row->followers}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Fullname', (isset($fields['fullname']['language'])? $fields['fullname']['language'] : array())) }}</td>
						<td>{{ $row->fullname}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Section Name', (isset($fields['section_name']['language'])? $fields['section_name']['language'] : array())) }}</td>
						<td>{{ $row->section_name}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Project Name', (isset($fields['project_name']['language'])? $fields['project_name']['language'] : array())) }}</td>
						<td>{{ $row->project_name}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	