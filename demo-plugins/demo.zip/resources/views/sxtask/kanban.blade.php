<div id="board" class="board">
 			
 				
 				@foreach ($tasks as $row)
 				<div class="tasks">
 					<div class="task-header"> 

			                    <h3 class="task-title mr-auto" > {{ $row['section']->section_name }}
			                    </h3><!-- .btn -->
			                    
			                    <a href="{{ url('sxtask/create?p='.$row['section']->project_id.'&section_id='.$row['section']->section_id) }}" class="btn  btn-xs"  
							title="{{ __('core.btn_create') }}" onclick="SximoModal(this.href); return false ;"><i class=" fa fa-plus "></i> </a>
			                    <!-- .dropdown -->
			                    <div class="dropdown">
			                      <!-- .btn -->
			                      <button class="btn btn-sm btn-icon text-muted" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></button> <!-- /.btn -->
			                      <!-- .dropdown-menu -->
			                      <div class="dropdown-menu dropdown-menu-right">
			                        <div class="dropdown-arrow"></div>
			                        		<a href="#" class="dropdown-item" draggable="false" onclick="SximoModal('{{ url('sxtask/section?id='.$row['section']->section_id) }}', '{{ $row['section']->section_name }}'); return false ; ">Edit</a>
			                        		<a href="#" class="dropdown-item" draggable="false">Trash</a>
			                      </div><!-- /.dropdown-menu -->
			                    </div><!-- /.dropdown -->
			                 
 					 </div>
 					<div class="task-body">
 						@foreach ($row['tasks'] as $task)
 						<div class="task-issue">
 							<div class="card">
 								<div class="card-header">
 									<h6 class="card-title"> {{ $task->task_name }} </h6>
 									<h6 class="card-subtitle text-muted">
                            <span class="text-muted">08:36</span> / <span class="text-muted">12:00</span> <span class="mx-1">·</span> <span class="due-date"><i class="far fa-fw fa-clock"></i> In 2 days</span>
                          </h6>
 								</div>

 								<div class="card-body" onclick="SximoModal('{{ url('sxtask/'.$task->task_id.'?p='.$row['section']->project_id) }}', '{{ $task->task_name }}'); return false ; " style="cursor: pointer;">
 									<div class="d-flex justify-content-between">
	                      				<label>Checklists</label> <span class="text-muted">({{ $task->todo }} / {{ $task->finished }} )</span>
	                    			</div>
 									<div class="progress progress-xs" style="height: 3px;">
									  <div class="progress-bar bg-success" role="progressbar" style="width: {{ $task->progress }}%" aria-valuenow="{{ $task->progress }}" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
 								</div>
 								<div class="card-footer">
 									<i class="fa fa-comment"></i> 12
 								</div>
 							</div>
 						</div>	
 					
 						@endforeach
 					</div>
 				</div>
 				@endforeach

 			
 		</div>	

 <style type="text/css">
 	
.board {
    display: block;
    padding: 1.5rem 1rem;
    white-space: nowrap;
    overflow-x: scroll;
    height: calc(100vh - 7rem)
}

.page-expanded .board {
    height: calc(100vh - 3.5rem)
}

@media (min-width:992px) {
    .board {
        padding-right: 2rem;
        padding-left: 2rem
    }
}

.board-list {
    margin: 0;
    padding: 0;
    white-space: auto;
    overflow-x: visible
}

.board-list,
.page-expanded .board-list {
    height: auto
}

.board-list .tasks {
    display: block;
    margin: 0;
    width: 100%;
    height: auto;
    max-width: 100%
}

.board-list .task-header {
    background-color: transparent;
    box-shadow: none
}

@media (min-width:576px) {
    .board-list .task-issue>.card {
        flex-direction: row
    }
    .board-list .task-issue>.card>.card-header {
        width: 240px
    }
    .board-list .task-issue>.card>.card-footer {
        border-top: 0
    }
}

.tasks {
    display: inline-flex;
    flex-direction: column;
    width: 20rem;
    height: 100%;
    vertical-align: top;
    background-color: #e6e8ed;
    box-shadow: 0 0 0 1px rgba(20, 20, 31, .05), 0 1px 3px 0 rgba(20, 20, 31, .15);
    border-radius: .25rem
}

.tasks:not(:last-child) {
    margin-right: 1.25rem
}

.tasks.hover {
    background-color: #d6d8e1
}

.tasks-action {
    display: inline-block;
    width: 18rem;
    padding: .5rem;
    vertical-align: top;
    background-color: #e6e8ed;
    box-shadow: 0 0 0 1px rgba(20, 20, 31, .05), 0 1px 3px 0 rgba(20, 20, 31, .15);
    border-radius: .25rem
}

.tasks-action:not(:last-child) {
    margin-right: 1.25rem
}

.task-header {
    padding: .5rem .75rem 0;
    display: flex;
    align-items: center;
    font-weight: 600
}

.task-header .btn-reset {
    padding: .5rem
}

.task-title {
    margin: 0;
    font-size: 16px !important;
}

.task-body {
    padding: .5rem;
    min-height: 2rem;
    flex: 1;
    overflow-x: hidden;
    overflow-y: auto
}

.task-issue {
    border-radius: .25rem
}

.task-issue:not(:last-child) {
    margin-bottom: .5rem
}

.task-issue>.card {
    margin-bottom: 0
}

.task-issue>.card>.card-header {
    border: 0;
    white-space: normal
}

.task-issue>.card>.card-header>a {
    color: inherit
}

.task-issue>.card>.card-header>a:focus,
.task-issue>.card>.card-header>a:hover {
    color: inherit;
    text-decoration: none
}

.task-label-group {
    margin: .125rem 0;
    display: block;
    line-height: 1;
    white-space: normal
}

.task-label {
    margin-right: .125rem;
    display: inline-block;
    width: 2rem;
    height: .5rem;
    border-radius: .5rem;
    background-color: #346cb0
}
.board .card-subtitle {
	font-size: 10px;
}
.board .card-footer {
	font-size: 12px;
	background:none;
}
.board .card-body,
.board .card-header
 {
 	padding: 10px;
 }

 </style>		
