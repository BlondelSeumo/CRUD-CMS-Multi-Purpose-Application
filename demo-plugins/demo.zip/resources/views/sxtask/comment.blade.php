
	@foreach($comments as $comm)
	<div class="comments">
		<div class="pics">
			{!! SiteHelpers::avatar(40) !!}
		</div>
		<div class="content">
			<small> {{ $comm->createdOn }}</small> <br />
			@if(Session('uid') == $comm->user_id)
			<button class="btn btn-xs text-danger pull-right" onclick="deleteItems('comment','<?php echo $comm->comment_id;?>');"><i class="fa fa-times"></i></button>
			@endif
			<div> {!! $comm->content !!} </div>
		</div>
	</div>
	@endforeach
