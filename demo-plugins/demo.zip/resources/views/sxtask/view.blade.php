<div class="task-view-detail " >

	
		<div class="editor_edit">
	  		<div class="row">
	  			<div class="col-md-4 col-xs-12">
	  				<div class="form-group "  >
	  					<label for="Project Id" > Project </label>
	  					<div>
	  						{{ $row->project_name }}
	  					</div>
	  				</div>	
	  			</div>

	  			<div class="col-md-4 col-xs-6">
	  				<div class="form-group "  >
	  					<label for="Project Id" > Section </label>
	  					<div>{{ $row->section_name}}</div>
	  				</div>	
	  			</div>
	  			<div class="col-md-4 col-xs-6">
	
	  				<div class="form-group "  >
	  					<label for="Project Id" > Assign To </label>
	  					<select class="form-control form-control-sm" name='assigned_to' onchange="re_assigned_to(this.value)">
	  						<option value="0"> Please select </option>
	  						@foreach($teams as $team)
	  						<option value="{{ $team['id'] }}" @if($team['id'] == $row->assigned_to) selected @endif > {{ $team['name'] }}</option>
	  						@endforeach
	  					</select>
	  				</div>	
	  			</div>
	  		</div>	

	  		<div class="row">
	  			<div class="col-md-4  col-xs-4">
	  				<div class="form-group "  >
	  					<label for="Project Id" ><i class="fa fa-clock-o"></i> Start Date </label>
	  					<div> {{ $row->start_date}}</div>
	  				</div>	
	  			</div>
	  			<div class="col-md-4 col-xs-4">
	  				<div class="form-group "  >
	  					<label for="Project Id" ><i class="fa fa-clock-o"></i> End Date </label>
	  					<div> {{ $row->end_date}}</div>
	  				</div>	
	  			</div>
	  			<div class="col-md-4  col-xs-4">
	  				<div class="form-group "  >
	  					<label for="Project Id" > Status </label>
	  					<select class="form-control form-control-sm" name='task_status' onchange="re_status_to(this.value)">
	  						@foreach($option_status as $os)
	  						<option value="{{ $os }}" @if($os == $row->task_status) selected @endif > {{ $os }}</option>
	  						@endforeach
	  					</select>
	  					
	  				</div>	
	  			</div>
	  		</div>	
	  		<hr />
	  		<div class="row">
	  			<div class="col-md-12">
	  				<label> Brief Task </label>
	  					<div class=""> 
	  						{!! $row->task_desc !!} 
	  					</div>
	  					
	  					
	  				
	  				
	  			</div>

	  		</div>
	  		</div>

	  		<div class="editor_edit" style="display: none; ">
	  			{!! Form::open(array('url'=>'sxtask?return='.$return, 'class'=>'form-horizontal validated sximo-form','files' => true ,'id'=> 'sxtaskTaskAjax' )) !!}
		  		<div class="row "  >
		  			<div class="col-md-12">
		  				
			  			<div  style="padding:10px; background-color: #f9f9fc; border:solid 1px #eee;">	 
							<div class="form-group">
								<label> Task Name / Title </label>
								<input type="text" class="form-control form-control-sm" value="{{ $row->task_name}}" name="task_name" />
							</div>
							<div class="form-group row">
								<div class="col-md-6">
									<input type="text" class="form-control form-control-sm date" value="{{ $row->start_date}}" name="start_date" />
								</div>
								<div class="col-md-6">
									<input type="text" class="form-control form-control-sm date" value="{{ $row->end_date}}" name="end_date" />
								</div>
							</div>
							<textarea class="form-control form-control-sm editor" name="task_desc" >{!! $row->task_desc !!} </textarea>
							<hr />
							<button type="submit" name="submit" class="btn btn-sm  btn-primary "> Save Change(s) </button>

						</div>
					</div>	
		  		</div>		
		  		<input type="hidden" name="action_task" value="save" />
		  		<input type="hidden" name="task_id" value="{{ $row->task_id }}" />
		  		<input type="hidden" name="project_id" value="{{ $row->project_id }}" />
				<input type="hidden" name="section_id" value="{{ $row->section_id }}" />
		  		{!! Form::close() !!}
		  	</div>		

	  		
	  		<div class="text-right mt-2 ">
	  			<a href="#" onclick="$('.editor_edit').toggle()"><i class="fa fa-pencil"></i> Edit Task Detail</a> 
			</div>
	  		<hr />
	  		<div class="row mt-3">
	  			<div class="col-md-12">
	  				<label for="Project Id" > Checklist To Do  <span style="font-size: 9px; font-style: italic; color: #ff9900;"> All task must be contain at least one checklist </span> </label>
	  				
	  				<div class="form-group "  >
	  					<input type="text" class="form-control form-control-sm todo_input" name="todo_name" id="todo_name" placeholder=" .... Type and enter .."/>
	  				</div>
	  				<div class="p-1" id="todo-list">
	  					
	  				</div>
	  			</div>

	  		</div>
	  		<hr />
	  		<div class="row">
	  			<div class="col-md-12">
	  				<label for="Project Id" > Comments </label>
	  				<div class="p-3">
	  					<div id="comment-data">
		  				
		  				</div>
	  					{!! Form::open(array('url'=>'sxtask?s=comment&return='.$return, 'class'=>'form-horizontal validated sximo-form','files' => true ,'id'=> 'commentForm' )) !!}
	  					<div class="comments">
	  						<div class="pics">
	  							{!! SiteHelpers::avatar(40) !!}
	  						</div>
	  						<div class="content">
	  							<textarea name="content" required class="form-control form-control-sm editor mb-4"></textarea>
	  							<input type="hidden" name="task_id" value="{{ $row->task_id }}">
	  							<input type="hidden" name="action_task" value="comment" />

	  							<button type="submit" name="submit" class="btn btn-sm btn-primary "> Send Comment </button>
	  						</div>
	  					</div>
	  					{!! Form::close() !!}
	  				</div>

	  			</div>

	  		</div>


</div>
	
<script src="{{ asset('sximo5/js/plugins/summernote/plugin')}}/summernote-ext-highlight.min.js"></script>	
<script type="text/javascript">
	$(document).ready(function() { 
		$.get( '<?php echo url('sxtask/todo?id='.$row->task_id);?>' ,function( data ) {
			$( '#todo-list').html( data );
			
		});
		$.get( '<?php echo url('sxtask/comment?id='.$row->task_id);?>' ,function( data ) {
			$( '#comment-data').html( data );
			
		});
		$(".select2").select2({ width:"98%"});	
		$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
		$('.todo_input').keypress(function (e) {
			if (e.which == 13) {
				$.post( "<?php echo url('sxtask');?>", { 
						task_id: "<?php echo $row->task_id;?>", 
						todo_name: $(this).val() ,
						action_task : 'todo'
					},function( data ){

					notyMessage(data.message);
					$('.ajaxLoading').hide(); 
					$.get( '<?php echo url('sxtask/todo?id='.$row->task_id);?>' ,function( data ) {
						$( '#todo-list').html( data );
						
					});
					$('.todo_input').val('')

				});
			}
		})

		//$.post( "<?php echo url('sxtask/todo?id='.$row->task_id);?>", { task_id: "John", todo_name: "" } );

		//$('.modal-dialog').addClass('modal-lg');
		$('.editor').summernote({ 
			height: 150 ,
	        toolbar: [
			 
			  ['font', ['bold', 'underline', 'clear']],
			  ['para', ['ul', 'ol', 'paragraph']],
			  ['table', ['table']],
			  ['insert', ['link', 'picture', 'video']],
			  ['view', ['fullscreen', 'codeview', 'help']],
			  ['highlight', ['highlight']]
			],
		});	
		 

	    var form = $('#commentForm'); 
        form.parsley();
        form.submit(function(){         
          if(form.parsley().isValid()){      
            var options = { 
              dataType:      'json', 
              beforeSubmit : function() {
                $('.ajaxLoading').show();
              },
			    success: function( data ) {
		          if(data.status == 'success')
		          {
		            notyMessage(data.message);$('.ajaxLoading').hide(); 
		            $('.ajaxLoading').hide();
		            $.get( '<?php echo url('sxtask/comment?id='.$row->task_id);?>' ,function( data ) {
						$( '#comment-data').html( data );
						
					});
		          } else {
		            notyMessageError(data.message);$('.ajaxLoading').hide();return false;
		            $('.ajaxLoading').hide();
		          }
			    }  
            }  
            $(this).ajaxSubmit(options); 
            return false;                 
          } else {
            return false;
          }   
        
        });

        var form = $('#sxtaskTaskAjax'); 
		form.parsley();
		form.submit(function(){
			
			if(form.parsley().isValid()){			
				var options = { 
					dataType:      'json', 
					beforeSubmit :  function(){

					},
					success:       function() {
						
						$('#sximo-modal').modal('hide');	
						refreshData();
						notyMessage(data.message);	
					
					}  
				}  
				$(this).ajaxSubmit(options); 
				return false;
							
			} else {
				return false;
			}		
		
		});	
		
	})
	function deleteItems( type , id ) {
		Swal.fire({
	        title: 'Confirm ?',
	        text: ' Are u sure deleting this record ? ',
	        type: 'warning',
	        showCancelButton: true,
	        confirmButtonText: 'Yes, please',
	        cancelButtonText: 'cancel'
	      }).then((result) => {
	        if (result.value) {
	        	if(type =='todo') {
		         	$.get( '<?php echo url('sxtask/todo_delete?id='.$row->task_id.'&todo_id=');?>'+ id ,function( data ) {
						$( '#todo-list').html( data );
						
					});
				}
				else {
					$.get( '<?php echo url('sxtask/comment_delete?id='.$row->task_id.'&comment_id=');?>'+ id ,function( data ) {
						$( '#comment-data').html( data );
						
					});
				}	
	          
	        }
	      })
	}
	function re_assigned_to(id) {
		Swal.fire({
	        title: 'Confirm ?',
	        text: ' Are u sure re-assigned  ? ',
	        type: 'warning',
	        showCancelButton: true,
	        confirmButtonText: 'Yes, please',
	        cancelButtonText: 'cancel'
	      }).then((result) => {
	        if (result.value) {
	        	
	         	$.get( '<?php echo url('sxtask/re_assigned?id='.$row->task_id.'&u=');?>'+ id ,function( data ) {
					ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data?p={{ $filter}}');
					notyMessage(data.message);	
					
				});	          
	        }
	      })
	}	
	function re_status_to(id) {
		Swal.fire({
	        title: 'Confirm ?',
	        text: ' Are u sure to change status  ? ',
	        type: 'warning',
	        showCancelButton: true,
	        confirmButtonText: 'Yes, please',
	        cancelButtonText: 'cancel'
	      }).then((result) => {
	        if (result.value) {
	        	
	         	$.get( '<?php echo url('sxtask/re_status?id='.$row->task_id.'&u=');?>'+ id ,function( data ) {
					ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data?p={{ $filter}}');
					notyMessage(data.message);	
					
				});	          
	        }
	      })
	}	

</script>	
<style type="text/css">
	/*
	.task-view-detail input ,
	.task-view-detail textarea ,
	.task-view-detail select 
	 {

		border: none ;
		padding: 0;

	}
	*/
	.task-view-detail {
		padding: 10px 10px;
	}
	.task-view-detail label{
		font-weight: 700;
	}

	.task-view-detail ul.checklist-todo{
		list-style: none;
		padding: 0;
		margin: 0 0 20px 20px;
		
	}
	.task-view-detail ul.checklist-todo li{
		line-height: 25px;
	}

	.task-view-detail .comments{
		display: flex;
		margin-bottom: 20px;
	}
	.task-view-detail .comments .pics{
		width: 60px;
		float: left ;
		position: absolute;
	}
	.task-view-detail .comments .content{
		
		margin-left: 70px; ;
		width: 100%;
	}
	.checklist-todo-item  span{
		padding-left: 10px;
		
	}
	.checklist-todo-item.done span {
		text-decoration: line-through #111;
	}

</style>

