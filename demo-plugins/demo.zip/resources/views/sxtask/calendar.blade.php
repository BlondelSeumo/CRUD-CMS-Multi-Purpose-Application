<script src="{{ asset('sximo5/js/plugins/fullcalendar/lib/moment.min.js') }}"></script>
<script src="{{ asset('sximo5/js/plugins/fullcalendar/fullcalendar/fullcalendar.min.js') }}"></script>

<link href="{{ asset('sximo5/js/plugins/fullcalendar/fullcalendar/fullcalendar.css') }}" rel='stylesheet' />
<div class="table-container">
	
	<div id='calendar' ></div>
</div>
<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek'
			},
			defaultDate: '<?php echo date("Y-m-d");?>',
			editable: true,
			resizable:true ,
			events:  <?php echo $calendar;?> ,
			eventClick: function(info) {
			  //  info.jsEvent.preventDefault(); // don't let the browser navigate
			//  info.jsEvent.preventDefault()
				SximoModal('{{ url('sxtask') }}/'+ info.id +'?p='+ info.project_id, info.title); 
			    //alert( JSON.stringify(info.id))
			  },
			eventDrop: function(info) {
			  console.log( info)
			},
			eventResize: function(info) {
					console.log( info)
			}
		});
		
	});

</script>
<style>



	#calendar {
		width: 100%;
		background-color: #fff;
		padding: 10px;
	
	}

</style>