
	{!! Form::open(array('url'=>'sxtask?return='.$return, 'class'=>'form-horizontal validated sximo-form','files' => true ,'id'=> 'sxtaskTaskAjax' )) !!}
	
	
	  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

	  		
	  			
	  		<div class="row">
	  			<div class="col-md-12">
	  				<div class="form-group "  >
	  					<label for="Project Id" > Assign To </label>
	  					<select class="form-control form-control-sm" name='assigned_to'>
	  						@foreach($teams as $team)
	  						<option value="{{ $team['id'] }}"> {{ $team['name'] }}</option>
	  						@endforeach
	  					</select>
	  				</div>		
	  			</div>

	  			<div class="col-md-12">
	  				<div class="form-group "  >
	  					<label for="Project Id" > Task Name </label>
	  				 <input  type='text' name='task_name' id='task_name' value='{{ $row['task_name'] }}' 
						     class='form-control form-control-sm ' />
					</div>	      
	  			</div>

	  		</div>

	  		<div class="row">
	  			<div class="col-md-12 mb-3">
	  				<textarea class="form-control form-control-sm editor" name="task_desc"> </textarea>
	  			</div>

	  		</div>
	  		<div class="row">
	  			<div class="col-md-6">
	  				<div class="form-group "  >
	  					<label  > Start Date </label>
	  					<input  type='text' name='start_date' id='end_date'  class='form-control form-control-sm date ' /> 
	  				</div>	
	  			</div>
	  			<div class="col-md-6">
	  				<div class="form-group "  >
	  					<label for="Project Id" > End Date </label>
	  					<input  type='text' name='end_date' id='end_date'  class='form-control form-control-sm date ' /> 
	  					
	  				</div>	
	  			</div>
	  			
	  		</div>
	  		<div class="row">
	  			<div class="col-md-12 mb-3">
	  			<button class="btn btn-sm btn-block btn-primary"> Save New Task</button>

	  		</div>


	  </div>
	  

		
		<input type="hidden" name="action_task" value="save" />
		<input type="hidden" name="project_id" value="{{ $filter }}" />
		<input type="hidden" name="section_id" value="{{ $section_id }}" />
		
			
	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		$('.editor').summernote({ height: 250});
		$(".select2").select2({ width:"98%"});	
		$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
		$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 

		var form = $('#sxtaskTaskAjax'); 
		form.parsley();
		form.submit(function(){
			
			if(form.parsley().isValid()){			
				var options = { 
					dataType:      'json', 
					beforeSubmit :  function(){

					},
					success:       function() {
						//ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data?p={{ $filter}}');
						$('#sximo-modal').modal('hide');	
						refreshData();
						notyMessage(data.message);	
					
					}  
				}  
				$(this).ajaxSubmit(options); 
				return false;
							
			} else {
				return false;
			}		
		
		});	
		
	});
	</script>		 
