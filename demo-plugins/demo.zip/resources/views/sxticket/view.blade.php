@extends('layouts.app')

@section('content')
<?php
$status_opt = array( 'New' => 'New' ,  'Processed' => 'Processed' ,  'Pending' => 'Pending' ,  'Closed' => 'Closed' , ); ?>

<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2></div>

<div class="toolbar-nav">
	<div class="row">
		<div class="col-md-9 ">			
			<a href="{{ url('sxticket?return='.$return) }}" class="tips btn btn-default  btn-sm  " title="{{ __('core.btn_back') }}"><i class="fa  fa-times"></i></a>
		</div>
		<div class="col-md-3 text-right">
			<div class="input-group">
				<div class="input-group-prepend">
					<button type="button" class="btn btn-success btn-sm " style="text-transform: none; color:#fff;"> Update Status </button>
				</div>	
	   			<select class="form-control form-control-sm" onchange="UpdateStatus(this.value)">
			      		<option value=""> --  Set status -- </option>
			      		@foreach($status_opt as $key=> $val )
			      			<option value="{{ $key }}"> {{ $val }}</option>
			      		@endforeach
			    </select>			
			</div>    	
		
		</div>	
	</div>
</div>
<div class="table-container">
<div class="pt-3  ">		

	<div class="list-group sximo-tickets">
				
				<li class="list-group-item list-group-item-action w-100  d-flex justify-content-between" style="min-height: 120px; background-color: #FFF3E0">
					<div style="width: 100px; float: left; position: absolute; min-height: 120px"> 
						
						<img src="{{ asset('uploads/users/'.$row->avatar)}}" class="avatar" width="80" alt="...">
						
					</div>
					<div class="w-100 " style="padding-left: 120px;">
						<div class="mb-2  ">
							<h5>	{{ $row->subject}} 
							<small style="float: right; position: relative; ">	
					      	
					      	
					      	
					      </small>
					      </h5>
						</div>
						<div  class=" w-100 ticket-body">
							{!! $row->content !!}

							<div class="pt-3">
								<b> Related Project / Product  : </b>  <br />
								<b> Category : </b> {{ $row->category }} <br />
								<b> Attachment : </b>
								<b> Created at : </b> {{ $row->createdOn }} 
							</div>
						</div>
						<div class="ticket-footer">
							<button class="btn btn-sm btn-danger "><b> Priority </b> :  {{ $row->priority }} </button>
							<button class="btn btn-sm btn-success "><b> Status </b> :  {{ $row->status }} </button>
						</div>
					</div>
				</li>
				@foreach($replies as $reply)
				<li class="list-group-item list-group-item-action " style="min-height: 120px;">
					<div style="width: 100px; float: left; position: absolute; min-height: 120px"> 
						
						{!! SiteHelpers::avatar(80) !!}
						
					</div> 
					<div class="w-100 " style="padding-left: 120px;">
						<div  class=" w-100 ticket-body">
							<h5>
								<small style="float: right; position: relative; "> 
									@if( Session('uid') == $reply->user_id )
										<a href="{{ url('sxticket/delete_reply?id='.$reply->ticke_id.'&r='.$reply->parent_id) }}" onclick="SximoConfirmDelete(this.href); return false" class="btn btn-default btn-sm"  title="{{ __('core.btn_remove') }}">  <i class="fa fa-trash-o"></i>  </a>
									@endif	
								</small>
							</h5>	
							{!! $reply->content !!}

							<div class="pt-3">

								<b> Attachment : </b> <br />
								<b> Replied at : </b> {{ $reply->createdOn }} 
							</div>
						</div>
						<div class="ticket-footer">
							
						</div>
					</div>	

				</li>

				@endforeach

				<li class="list-group-item list-group-item-action " style="min-height: 120px;">
					{!! Form::open(array('url'=>'sxticket?return='.$return, 'class'=>'form-vertical validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
					<div style="width: 100px; float: left; position: absolute; min-height: 120px"> 
						
						{!! SiteHelpers::avatar(80) !!}
						
					</div> 
					<div class="w-100 justify-content-between " style="padding-left: 120px;">
						
							
						<div class="form-group">
							<label>	Write Reply :   </label>
							<textarea class="form-control editor " name="content" required=""></textarea>

						</div>
						<div class="form-group">
								<input type="file" name=""> 
						</div>
						<div class="form-group">
								<button type="submit" class="btn btn-primary"> Send Reply </button>
								{!! Form::hidden('parent_id', $row->ticke_id) !!}	
								{!! Form::hidden('user_id', Session('uid') ) !!}	
						</div>
					</div>
					<input type="hidden" name="action_task" value="reply" />
					{!! Form::close() !!}
				</li>


	</div>				
	

</div>
</div>
<script src="{{ asset('sximo5/js/plugins/summernote/plugin')}}/summernote-ext-highlight.min.js"></script>	
<script type="text/javascript">
	$(document).ready(function() { 
		
		$('.editor').summernote({ 
			height: 250 ,
	        toolbar: [
			 
			  ['font', ['bold', 'underline', 'clear']],
			  ['fontname', ['fontname']],
			  ['color', ['color']],
			  ['para', ['ul', 'ol', 'paragraph']],
			  ['table', ['table']],
			  ['insert', ['link', 'picture', 'video']],
			  ['view', ['fullscreen', 'codeview', 'help']],
			  ['highlight', ['highlight']]
			],
		});	
	})
	function UpdateStatus( status ) {

		Swal.fire({
	        title: 'Update Status ?',
	        text: ' Are u sure continue this proccess ? ',
	        type: 'warning',
	        showCancelButton: true,
	        confirmButtonText: 'Yes, please',
	        cancelButtonText: 'cancel'
	      }).then((result) => {
	        if (result.value) {
	          window.location.href = '<?php echo url('sxticket/update_status?id='.$row->ticke_id.'&s=');?>' + status ;
	          
	        }
	      })

		return false;
	}
</script>		

<style type="text/css">
	.sximo-tickets {

	}
	.ticket-body {
		
		padding: 15px 0;
		border-right: none ;
		border-left: none ;
	}
	.ticket-footer{
		margin-bottom: 20px;
		padding: 20px 0;
	}

</style>
@stop
