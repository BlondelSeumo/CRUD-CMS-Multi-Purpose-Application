@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>
<div class="toolbar-nav" >   
	<div class="row">
		<div class="col-md-4 text-right">
			<div class="input-group ">
		     
		      <input type="text" class="form-control form-control-sm onsearch" data-target="{{ url($pageModule) }}" aria-label="..." placeholder=" Type And Hit Enter ">
		    </div>
		</div> 

		<div class="col-md-8 text-right"> 	
			
			
			 @if(Session('gid') =='1' || Session('gid') =='2')
		    <a href="javascript:;" class="btn  btn-sm"  
				title="{{ __('core.btn_create') }}" onclick="$('#ticket-setting').toggle()"> Settings </a>
			@endif
			<div class="btn-group">
				<button type="button" class="btn btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Bulk Action </button>
		        <ul class="dropdown-menu">
		        @if($access['is_remove'] ==1)
					 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="{{ __('core.btn_remove') }}">
					Remove Selected </a></li>
				@endif 
				<div class="dropdown-divider"></div>
		        @if($access['is_excel'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=excel&return='.$return) }}" class="nav-link "> Export Excel </a></li>	
				@endif
				@if($access['is_csv'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=csv&return='.$return) }}" class="nav-link "> Export CSV </a></li>	
				@endif
				@if($access['is_pdf'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=pdf&return='.$return) }}" class="nav-link "> Export PDF </a></li>	
				@endif
				@if($access['is_print'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=print&return='.$return) }}" class="nav-link "> Print Document </a></li>	
				@endif
				<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule) }}"  class="nav-link "> Clear Search </a></li>
		          	
		        
		          
		        </ul>

		    </div>    
		   	
			@if($access['is_add'] ==1)
			<a href="{{ url('sxticket/create?return='.$return) }}" class="btn  btn-sm btn-primary"  
				title="{{ __('core.btn_create') }}"><i class=" fa fa-plus "></i> Create New </a>
			@endif
		</div>
		   
	</div>	

</div>	
<div class="card">
			 @if(Session('gid') =='1' || Session('gid') =='2')
			 <div class="card-body">
			<fieldset id="ticket-setting" style="display: none;">
				<legend> Ticket Configuration </legend>
				{!! Form::open(array('url'=>'sxticket?'.$return, 'class'=>'form-horizontal m-t'  )) !!}
				<div class="row">
					<div class="col-md-6">
						<h6> Categories </h6>
						<p style="font-size: 10px;"> <i>Dont change category name after used by ticket , it will not work </i></p>
						@foreach( $setting['categories'] as $key=> $val)
						<div class="form-group row clonedInput clone ">
							<div class="col-md-12">
								<div class="input-group ">									
									<input type="text" class="form-control form-control-sm" placeholder="Type Category" name="category[]" value="{{ $val[0] }}" />
			      					<div class="input-group-append">
			      						<button type="button" class="btn btn-sm btn-default"> Assign To : </button>
			      					</div>
			      					<select class="form-control form-control-sm" name="team[]">
			      						<option value="" > Select Team </option>
			      						@foreach($teams as $team)
			      						<option value="{{ $team->team_id }}" @if($val[1] == $team->team_id) selected @endif >{{ $team->team_name }}</option>
			      						@endforeach
			      					</select>
			      					<div class="input-group-append">
			      						<button type="button" class="btn btn-sm btn-danger " onclick="$(this).parent().parent().parent().parent().fadeIn(function(){ $(this).remove() }); return false"> <i class="fa fa-minus"></i></button>
			      					</div>
								
								</div>
							</div>	
						</div>
						@endforeach

						<div class="row">
							<div class="col-md-6">
								
							</div>
							<div class="col-md-6 text-right">
								<button type="button" class="btn btn-sm btn-success addC" rel=".clone"> <i class="fa fa-plus"></i> New </button>
							</div>
						</div>	
						
					</div>
					<div class="col-md-6">
						<h6> Connection to 3nd party module </h6>
						<p ><i>  Please make sure u have module installed if you want to use this plugin </i></p>
						<div class="form-check mb-2">
							<label class="col-md-12 mb-2">Connect to project management</label> <br />
							<input class="minimal-green" value="1" name="project" type="checkbox" @if($setting['project']=='1') checked @endif > Enabled 

						</div>
						
						
						<div class="form-check ">
							<label class="col-md-12 mb-2"> Connect to Issue Tracker</label> <br />
							<input class="minimal-green" value="1" name="issue" type="checkbox" @if($setting['issue'] =='1') checked @endif > Enabled 

						</div>
					
					</div>					
				</div>	
				<hr />
				<div class="text-center">
					<button type="submit" class="btn btn-sm btn-primary "> <i class="fa fa-save"></i> Save Settings </button>
				</div>	
				<input type="hidden" name="action_task" value="categories" />	
				{!! Form::close() !!}

			</fieldset>
		</div>
			@endif

			<!-- Table Grid -->
			
 			{!! Form::open(array('url'=>'sxticket?'.$return, 'class'=>'form-horizontal m-t' ,'id' =>'SximoTable' )) !!}
			
		    <table class="table  " id="{{ $pageModule }}Table">
		        <thead>
					<tr>
						<th style="width: 3% !important;" class="number"> No </th>
						<th  style="width: 3% !important;"> <input type="checkbox" class="checkall minimal-green" /></th>
						<th> ID / Date </th>
						<th> </th>
						<th width="50%" style="width: 50% !important"> Sender / Subject </th>
						<th> Category </th>
						
						<th> Status  </th>
						<th> Assigned  </th>
						

						
					  </tr>
		        </thead>

		        <tbody>        						
		            @foreach ($rowData as $row)
		                <tr >
							<td class="thead"> {{ ++$i }} </td>
							<td class="tcheckbox"><input type="checkbox" class="ids minimal-green" name="ids[]" value="{{ $row->ticke_id }}" />  </td>
									
							<td> # {{ $row->ticke_id }} <br /> {{  date("d/m/Y", strtotime($row->createdOn))  }}</td>
							<td>
								<img src="{{ asset('uploads/users/'.$row->avatar)}}" class="avatar" width="40" alt="...">
							 	
							</td>
							<td>
								Created By : <b> {{ $row->username }} </b>  (	{{ $row->email }} )
								<p style="font-size: 14px;" class="pt-3">
									<a href="{{ url('sxticket/'.$row->ticke_id.'?return='.$return)}}"> {{ $row->subject }} </a> 
								</p>
							</td>
							<td> 
								 {{ $row->category }}  <br />
								

							</td>
							<td class="status-{{ $row->status }}"> 
								<b> Priority : </b> {{ $row->priority }}  <br />
								<b> Status  :  {{ $row->status }} </b> 

							</td>
							<td>  </td>
							
		                </tr>
						
		            @endforeach
		              
		        </tbody>
		      
		    </table>
			<input type="hidden" name="action_task" value="" />
			
			{!! Form::close() !!}
			
			
			<!-- End Table Grid -->

</div>
@include('footer')
<script>
$(document).ready(function(){
	$('.addC').relCopy({});
	$('.copy').click(function() {
		var total = $('input[class="ids"]:checkbox:checked').length;
		if(confirm('are u sure Copy selected rows ?'))
		{
			$('input[name="action_task"]').val('copy');
			$('#SximoTable').submit();// do the rest here	
		}
	})	
	
});	
</script>	
<style type="text/css">
	tr td.status-New  {
		background-color: #FFF3E0;
	}
	tr td.status-Completed  {
		background-color: #1B5E20;
		color: #fff !important;
	}
	tr td.status-Pending  {
		background-color: #FFF3E0;
	}
	tr td.status-Processed  {
		background-color: #E8F5E9;
	}	
</style>
	
@stop
