

		 {!! Form::open(array('url'=>'sxticket', 'class'=>'form-vertical','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Ticket Info</legend>
				{!! Form::hidden('ticke_id', $row['ticke_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Category    </label>									
										  
					<?php $category = explode(',',$row['category']);
					$category_opt = array( 'marketing' => 'Marketing' ,  'billing' => 'Billing' ,  'technical' => 'Technical Support' , ); ?>
					<select name='category' rows='5' required  class='select2 '  > 
						<?php 
						foreach($category_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['category'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Related Project / Product ?    </label>									
										  <input  type='text' name='project_id' id='project_id' value='{{ $row['project_id'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Created By    </label>									
										  <select name='user_id' rows='5' id='user_id' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Assigned    </label>									
										  <input  type='text' name='assigned' id='assigned' value='{{ $row['assigned'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Priority    </label>									
										  
					<?php $priority = explode(',',$row['priority']);
					$priority_opt = array( 'low' => 'Low' ,  'medium' => 'Medium' ,  'high' => 'High' , ); ?>
					<select name='priority' rows='5' required  class='select2 '  > 
						<?php 
						foreach($priority_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['priority'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Status    </label>									
										  
					<?php $status = explode(',',$row['status']);
					$status_opt = array( 'new' => 'New' ,  'process' => 'Processed' ,  'pending' => 'Pending' ,  'closed' => 'Closed' , ); ?>
					<select name='status' rows='5' required  class='select2 '  > 
						<?php 
						foreach($status_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['status'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 						
									  </div> 
				</div>
				
				<div class="col-md-12">
						<fieldset><legend> Ticket Content</legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Subject    </label>									
										  <input  type='text' name='subject' id='subject' value='{{ $row['subject'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Content    </label>									
										  <textarea name='content' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['content'] }}</textarea> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Attachment    </label>									
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-copy"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="attachment" class="upload"       />
						</div>
						<div class="attachment-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["attachment"],"/uploads/ticket_attachments") !!}
						</div>
					 						
									  </div> 
				</div>
				
				

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#user_id").jCombo("{!! url('sxticket/comboselect?filter=tb_users:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["user_id"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
