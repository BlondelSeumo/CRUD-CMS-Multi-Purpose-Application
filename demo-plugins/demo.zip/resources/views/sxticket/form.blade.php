@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'sxticket?return='.$return, 'class'=>'form-vertical validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			
			<div class="col-md-6 " >
				<div class="submitted-button">
					<button name="apply" class="tips btn btn-sm   "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-check"></i> Send Ticket Now </button>
					
				</div>	
			</div>
			<div class="col-md-6 text-right " >
				<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn   btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a> 
			</div>
		</div>
	</div>	
<div class="card">

	<div class="card-body">
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	<div class="col-md-12">
						<fieldset><legend> Ticket Info</legend>
				{!! Form::hidden('ticke_id', $row['ticke_id']) !!}	
				{!! Form::hidden('user_id', Session('uid') ) !!}	
				{!! Form::hidden('status', 'new' ) !!}	

					<div class="row">
						<div class="col-md-6">			
						  	<div class="form-group  " >
								<label for="ipt" class=" control-label "> Category    </label>									
								  
								<?php $category = explode(',',$row['category']);
								$category_opt = array( 'marketing' => 'Marketing' ,  'billing' => 'Billing' ,  'technical' => 'Technical Support'  ); ?>
								<select name='category' rows='5' required  class='select2 '  > 
								<?php 
								foreach($category_opt as $key=>$val)
								{
									echo "<option  value ='$key' ".($row['category'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
								}						
								?></select> 						
							</div> 	
						</div>	
						<div class="col-md-6">						
										<div class="form-group  " >
											<label for="ipt" class=" control-label "> Related Project / Product ?    </label>									
										  	<input  type='text' name='project_id' id='project_id' value='{{ $row['project_id'] }}' class='form-control form-control-sm ' /> 						
										</div> 	
						</div>
					</div>						
 					
					  
					  <div class="form-group  " >
						<label for="ipt" class=" control-label "> Priority    </label>									
						  
						<?php $priority = explode(',',$row['priority']);
						$priority_opt = array( 'low' => 'Low' ,  'medium' => 'Medium' ,  'high' => 'High' , ); ?>
						<select name='priority' rows='5' required  class='select2 '  > 
							<?php 
							foreach($priority_opt as $key=>$val)
							{
								echo "<option  value ='$key' ".($row['priority'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
							}						
							?></select> 						
					  </div> 					
									  
				</div>
				
				<div class="col-md-12">
						<fieldset><legend> Ticket Content</legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Subject    </label>									
										  <input  type='text' name='subject' id='subject' value='{{ $row['subject'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Content    </label>									
										  <textarea name='content' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['content'] }}</textarea> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Attachment    </label>									
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-copy"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="attachment" class="upload"       />
						</div>
						<div class="attachment-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["attachment"],"/uploads/ticket_attachments") !!}
						</div>
					 						
									  </div> 
									  </fieldset>	
					</div>
				
				
	
		</div>
		
		<input type="hidden" name="action_task" value="save" />
		
		</div>
	</div>		
	{!! Form::close() !!}
 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#user_id").jCombo("{!! url('sxticket/comboselect?filter=tb_users:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["user_id"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxticket/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop