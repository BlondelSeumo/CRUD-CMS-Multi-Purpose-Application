@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'orderdetail?return='.$return, 'class'=>'form-horizontal form-material validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			
			<div class="col-md-6 " >
				<div class="submitted-button">
					<button name="apply" class="tips btn btn-sm btn-primary  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
					<button name="save" class="tips btn btn-sm btn-success "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
				</div>	
			</div>
			<div class="col-md-6 text-right " >
				<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-warning  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a> 
			</div>
		</div>
	</div>	


	
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	<div class="col-md-12">
						<fieldset><legend> Order Details</legend>
									
									  <div class="form-group row  " >
										<label for="OrderDetailID" class=" control-label col-md-4 text-left"> OrderDetailID </label>
										<div class="col-md-8">
										  <input  type='text' name='OrderDetailID' id='OrderDetailID' value='{{ $row['OrderDetailID'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="OrderNumber" class=" control-label col-md-4 text-left"> OrderNumber </label>
										<div class="col-md-8">
										  <input  type='text' name='orderNumber' id='orderNumber' value='{{ $row['orderNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="ProductCode" class=" control-label col-md-4 text-left"> ProductCode </label>
										<div class="col-md-8">
										  <input  type='text' name='productCode' id='productCode' value='{{ $row['productCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="QuantityOrdered" class=" control-label col-md-4 text-left"> QuantityOrdered </label>
										<div class="col-md-8">
										  <input  type='text' name='quantityOrdered' id='quantityOrdered' value='{{ $row['quantityOrdered'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="PriceEach" class=" control-label col-md-4 text-left"> PriceEach </label>
										<div class="col-md-8">
										  <input  type='text' name='priceEach' id='priceEach' value='{{ $row['priceEach'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="OrderLineNumber" class=" control-label col-md-4 text-left"> OrderLineNumber </label>
										<div class="col-md-8">
										  <input  type='text' name='orderLineNumber' id='orderLineNumber' value='{{ $row['orderLineNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>
	
		</div>
		
		<input type="hidden" name="action_task" value="save" />
		
		
				


	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("orderdetail/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop