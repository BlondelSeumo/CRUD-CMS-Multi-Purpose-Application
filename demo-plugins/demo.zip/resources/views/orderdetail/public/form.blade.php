

		 {!! Form::open(array('url'=>'orderdetail', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Order Details</legend>
									
									  <div class="form-group row  " >
										<label for="OrderDetailID" class=" control-label col-md-4 text-left"> OrderDetailID </label>
										<div class="col-md-8">
										  <input  type='text' name='OrderDetailID' id='OrderDetailID' value='{{ $row['OrderDetailID'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="OrderNumber" class=" control-label col-md-4 text-left"> OrderNumber </label>
										<div class="col-md-8">
										  <input  type='text' name='orderNumber' id='orderNumber' value='{{ $row['orderNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="ProductCode" class=" control-label col-md-4 text-left"> ProductCode </label>
										<div class="col-md-8">
										  <input  type='text' name='productCode' id='productCode' value='{{ $row['productCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="QuantityOrdered" class=" control-label col-md-4 text-left"> QuantityOrdered </label>
										<div class="col-md-8">
										  <input  type='text' name='quantityOrdered' id='quantityOrdered' value='{{ $row['quantityOrdered'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="PriceEach" class=" control-label col-md-4 text-left"> PriceEach </label>
										<div class="col-md-8">
										  <input  type='text' name='priceEach' id='priceEach' value='{{ $row['priceEach'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="OrderLineNumber" class=" control-label col-md-4 text-left"> OrderLineNumber </label>
										<div class="col-md-8">
										  <input  type='text' name='orderLineNumber' id='orderLineNumber' value='{{ $row['orderLineNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
