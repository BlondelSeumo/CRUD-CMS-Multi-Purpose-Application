<div class="form-ajax-box">
{!! Form::open(array('url'=>'dcustomer?return='.$return, 'class'=>'form-horizontal form-material sximo-form validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'dcustomerFormAjax')) !!}

	<div class="toolbar-nav">	
		<div class="row">	
			
			<div class="col-md-6">
							
			</div>
			<div class="col-sm-6 text-right">	
				<button type="submit" class="btn btn-sm  btn-primary " name="apply"> {{ Lang::get('core.sb_apply') }} </button>
				<button type="submit" class="btn btn-sm btn-success" name="save">  {{ Lang::get('core.sb_save') }} </button>
				<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm btn-danger  " title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>	
			</div>	
					
		</div>
	</div>	
		<div class="row">

	
	<div class="col-md-12">
						<fieldset><legend> Info</legend>
				{!! Form::hidden('customerNumber', $row['customerNumber']) !!}					
									  <div class="form-group row  " >
										<label for="CustomerName" class=" control-label col-md-4 text-left"> CustomerName <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='customerName' id='customerName' value='{{ $row['customerName'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="LastName" class=" control-label col-md-4 text-left"> LastName <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='contactLastName' id='contactLastName' value='{{ $row['contactLastName'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="FirstName" class=" control-label col-md-4 text-left"> FirstName </label>
										<div class="col-md-8">
										  <input  type='text' name='contactFirstName' id='contactFirstName' value='{{ $row['contactFirstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Sales" class=" control-label col-md-4 text-left"> Sales </label>
										<div class="col-md-8">
										  <input  type='text' name='salesRepEmployeeNumber' id='salesRepEmployeeNumber' value='{{ $row['salesRepEmployeeNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="CreditLimit" class=" control-label col-md-4 text-left"> CreditLimit </label>
										<div class="col-md-8">
										  <input  type='text' name='creditLimit' id='creditLimit' value='{{ $row['creditLimit'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 
				</div>
				
				<div class="col-md-12">
						<fieldset><legend> Address</legend>
									
									  <div class="form-group row  " >
										<label for="Phone" class=" control-label col-md-4 text-left"> Phone </label>
										<div class="col-md-8">
										  <input  type='text' name='phone' id='phone' value='{{ $row['phone'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine 1" class=" control-label col-md-4 text-left"> AddressLine 1 </label>
										<div class="col-md-8">
										  <input  type='text' name='addressLine1' id='addressLine1' value='{{ $row['addressLine1'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine 2" class=" control-label col-md-4 text-left"> AddressLine 2 </label>
										<div class="col-md-8">
										  <input  type='text' name='addressLine2' id='addressLine2' value='{{ $row['addressLine2'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="State" class=" control-label col-md-4 text-left"> State </label>
										<div class="col-md-8">
										  <input  type='text' name='state' id='state' value='{{ $row['state'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Posta lCode" class=" control-label col-md-4 text-left"> Posta lCode </label>
										<div class="col-md-8">
										  <input  type='text' name='postalCode' id='postalCode' value='{{ $row['postalCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Country" class=" control-label col-md-4 text-left"> Country <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='country' rows='5' id='country' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="City" class=" control-label col-md-4 text-left"> City </label>
										<div class="col-md-8">
										  <input  type='text' name='city' id='city' value='{{ $row['city'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 
				</div>
				
													
		
	<input type="hidden" name="action_task" value="save" />				
				


	

</div>		
{!! Form::close() !!}
</div>
@include('sximo.module.template.ajax.formjavascript')

<script type="text/javascript">
$(document).ready(function() { 
	
		$("#country").jCombo("{!! url('dcustomer/comboselect?filter=countries:country_name:country_name') !!}",
		{  selected_value : '{{ $row["country"] }}' });
		 
	
	 
				
	var form = $('#dcustomerFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  function(){
				},
				success: function(data) {
					if(data.status == 'success')
					{
						ajaxViewClose('#{{ $pageModule }}');
						var table = $('#dcustomerTable').DataTable();
						table.ajax.reload();
						notyMessage(data.message);	
						$('#sximo-modal').modal('hide');	
					} else {
						notyMessageError(data.message);	
						return false;
					}
				}  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

</script>		 