@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'formwizard?return='.$return, 'class'=>'form-horizontal form-material validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 
			</div>
			<div class="col-md-6  text-right " >
				<div class="submitted-button">
					<button name="apply" class="tips btn btn-sm btn-primary  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
					<button name="save" class="tips btn btn-sm btn-success "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
					<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-warning  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>
				</div>	
			</div>
			
		</div>
	</div>	


	
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	<div id="wizard-step" class="wizard-circle number-tab-steps"> <h3>Basic</h3> <section> {!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group row  " >
										<label for="Input Text" class=" control-label col-md-4 text-left"> Input Text <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='input_text' id='input_text' value='{{ $row['input_text'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Radio" class=" control-label col-md-4 text-left"> Input Radio <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
					
					<input type='radio' name='input_radio' value ='1' required @if($row['input_radio'] == '1') checked="checked" @endif class='filled-in' id='input_radio-0'> <label for='input_radio-0'>Option I </label>
					
					<input type='radio' name='input_radio' value ='2' required @if($row['input_radio'] == '2') checked="checked" @endif class='filled-in' id='input_radio-1'> <label for='input_radio-1'>Option II </label>
					
					<input type='radio' name='input_radio' value ='3' required @if($row['input_radio'] == '3') checked="checked" @endif class='filled-in' id='input_radio-2'> <label for='input_radio-2'>Option III </label> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Date" class=" control-label col-md-4 text-left"> Input Date <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
				
					{!! Form::text('input_date', $row['input_date'],array('class'=>'form-control form-control-sm date')) !!} 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Datetime" class=" control-label col-md-4 text-left"> Input Datetime <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
					{!! Form::text('input_datetime', $row['input_datetime'],array('class'=>'form-control form-control-sm datetime')) !!}
				 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Checkbox" class=" control-label col-md-4 text-left"> Input Checkbox <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <?php $input_checkbox = explode(",",$row['input_checkbox']); ?>
					  
					<input type='checkbox' name='input_checkbox[]' value ='1' required  class=' filled-in' id='input_checkbox-0'
					@if(in_array('1',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-0'> Value I </label> 
					  
					<input type='checkbox' name='input_checkbox[]' value ='2' required  class=' filled-in' id='input_checkbox-1'
					@if(in_array('2',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-1'> Value II </label> 
					  
					<input type='checkbox' name='input_checkbox[]' value ='3' required  class=' filled-in' id='input_checkbox-2'
					@if(in_array('3',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-2'> Value III </label>  
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Textarea" class=" control-label col-md-4 text-left"> Input Textarea <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <textarea name='input_textarea' rows='5' id='input_textarea' class='form-control form-control-sm '  
				         required  >{{ $row['input_textarea'] }}</textarea> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Textareaeditor" class=" control-label col-md-4 text-left"> Input Textareaeditor <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <textarea name='input_textareaeditor' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['input_textareaeditor'] }}</textarea> 
										 </div> 
										 
									  </div> </section> <h3>Upload</h3> <section> 					
									  <div class="form-group row  " >
										<label for="Input File" class=" control-label col-md-4 text-left"> Input File <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="input_file" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="input_file-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["input_file"],"/uploads/images/") !!}
						</div>
					 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Filemulti" class=" control-label col-md-4 text-left"> Input Filemulti <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
					<a href="javascript:void(0)" class="btn btn-xs btn-primary pull-right" onclick="addMoreFiles('input_filemulti')"><i class="fa fa-plus"></i></a>
					<div class="input_filemultiUpl multipleUpl">	
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-copy"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="input_filemulti[]" class="upload"       />
						</div>		
					</div>
					<ul class="uploadedLists " >
					<?php $cr= 0; 
					$row['input_filemulti'] = explode(",",$row['input_filemulti']);
					?>
					@foreach($row['input_filemulti'] as $files)
						@if(file_exists('./uploads/images/'.$files) && $files !='')
						<li id="cr-<?php echo $cr;?>" class="">							
							<a href="{{ url('/uploads/images//'.$files) }}" target="_blank" >
							{!! SiteHelpers::showUploadedFile( $files ,"/uploads/images/",100) !!}
							</a> 
							<span class="pull-right removeMultiFiles" rel="cr-<?php echo $cr;?>" url="/uploads/images/{{$files}}">
							<i class="fa fa-trash-o  btn btn-xs btn-danger"></i></span>
							<input type="hidden" name="currinput_filemulti[]" value="{{ $files }}"/>
							<?php ++$cr;?>
						</li>
						@endif
					
					@endforeach
					</ul>
					 
										 </div> 
										 
									  </div> </section> <h3>Select</h3> <section> 					
									  <div class="form-group row  " >
										<label for="Input Select" class=" control-label col-md-4 text-left"> Input Select <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
					<?php $input_select = explode(',',$row['input_select']);
					$input_select_opt = array( '1' => 'Value I' ,  '2' => 'Value II' ,  '3' => 'Value III' , ); ?>
					<select name='input_select' rows='5' required  class='select2 '  > 
						<?php 
						foreach($input_select_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['input_select'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Input Selectmulti" class=" control-label col-md-4 text-left"> Input Selectmulti <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='input_selectmulti[]' multiple rows='5' id='input_selectmulti' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Country Id" class=" control-label col-md-4 text-left"> Country Id <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='country_id' rows='5' id='country_id' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="State Id" class=" control-label col-md-4 text-left"> State Id <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='state_id' rows='5' id='state_id' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="City Id" class=" control-label col-md-4 text-left"> City Id <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='city_id' rows='5' id='city_id' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> </section></div>
	
		</div>
		
		<input type="hidden" name="action_task" value="save" />
		
		
				


	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#input_selectmulti").jCombo("{!! url('formwizard/comboselect?filter=products:productCode:productName') !!}",
		{  selected_value : '{{ $row["input_selectmulti"] }}' });
		
		$("#country_id").jCombo("{!! url('formwizard/comboselect?filter=countries:country_id:country_name') !!}",
		{  selected_value : '{{ $row["country_id"] }}' });
		
		$("#state_id").jCombo("{!! url('formwizard/comboselect?filter=states:state_id:state_name') !!}&parent=country_id:",
		{  parent: '#country_id', selected_value : '{{ $row["state_id"] }}' });
		
		$("#city_id").jCombo("{!! url('formwizard/comboselect?filter=cities:city_id:city_name') !!}",
		{  selected_value : '{{ $row["city_id"] }}' });
		 	
		
			$(".submitted-button").hide()
			$("#wizard-step").steps({
		          headerTag: "h3",
		          bodyTag: "section",
		          transitionEffect: "fade",
		          titleTemplate: "<span class='step'>#index#</span> #title#",
		          autoFocus: true,
		          labels: {
		            finish: "Submit"
		        },
		        onFinished: function (event, currentIndex) {
		          $("#saved-button").click();
		        }
		     });
	       	$(".steps ul > li > a span").removeClass("number") 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("formwizard/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop