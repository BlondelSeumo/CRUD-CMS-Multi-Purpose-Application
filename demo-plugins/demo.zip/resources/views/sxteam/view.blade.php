@if($setting['view-method'] =='native')
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md=6" >
				<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm  " title="{{ __('core.btn_back') }}"><i class="fa  fa-times"></i></a>		
			</div>
			<div class="col-md-6 text-right" >
		   		<a href="{{ ($prevnext['prev'] != '' ? url('sxteam/'.$prevnext['prev'].'?return='.$return ) : '#') }}" class="tips btn btn-sm" onclick="ajaxViewDetail('#sxteam',this.href); return false; "><i class="fa fa-arrow-left"></i>  </a>	
				<a href="{{ ($prevnext['next'] != '' ? url('sxteam/'.$prevnext['next'].'?return='.$return ) : '#') }}" class="tips btn btn-sm " onclick="ajaxViewDetail('#sxteam',this.href); return false; "> <i class="fa fa-arrow-right"></i>  </a>					
			</div>	

			
		</div>
	</div>	
		<div class="p-5">
@endif	

		<table class="table  table-bordered" >
			<tbody>	
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Team Id', (isset($fields['team_id']['language'])? $fields['team_id']['language'] : array())) }}</td>
						<td>{{ $row->team_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('User Ids', (isset($fields['user_ids']['language'])? $fields['user_ids']['language'] : array())) }}</td>
						<td>{{ $row->user_ids}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Team Name', (isset($fields['team_name']['language'])? $fields['team_name']['language'] : array())) }}</td>
						<td>{{ $row->team_name}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Team Desc', (isset($fields['team_desc']['language'])? $fields['team_desc']['language'] : array())) }}</td>
						<td>{{ $row->team_desc}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('CreatedOn', (isset($fields['createdOn']['language'])? $fields['createdOn']['language'] : array())) }}</td>
						<td>{{ $row->createdOn}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('UpdatedOn', (isset($fields['updatedOn']['language'])? $fields['updatedOn']['language'] : array())) }}</td>
						<td>{{ $row->updatedOn}} </td>
						
					</tr>
				
			</tbody>	
		</table>  
			
		 	
		 
@if($setting['form-method'] =='native')
	</div>	

@endif		