

		 {!! Form::open(array('url'=>'sxteam/savepublic', 'class'=>'form-vertical','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> sxteam</legend>
				{!! Form::hidden('team_id', $row['team_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Users    </label>									
										  <select name='user_ids[]' multiple rows='5' id='user_ids' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Team Name    </label>									
										  <input  type='text' name='team_name' id='team_name' value='{{ $row['team_name'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Team Desc    </label>									
										  <textarea name='team_desc' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['team_desc'] }}</textarea> 						
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#user_ids").jCombo("{!! url('sxteam/comboselect?filter=tb_users:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["user_ids"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
