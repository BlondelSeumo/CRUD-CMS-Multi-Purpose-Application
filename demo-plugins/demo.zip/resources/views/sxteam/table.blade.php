<?php usort($tableGrid, "SiteHelpers::_sort"); ?>

	 {!! (isset($search_map) ? $search_map : '') !!}
	 	@include($pageModule.'/toolbar')
	 <?php echo Form::open(array('url'=>'sxteam', 'class'=>'form-horizontal' ,'id' =>'SximoTable'  ,'data-parsley-validate'=>'' )) ;?>
<div class="table-container" >	
	<div class="card">
		<table class="table">
			<tbody>
				<?php foreach ($rowData as $row) :?>
				<tr>
					<td width="30" ><input type="checkbox" class="ids minimal-green" name="ids[]" value="<?php echo $row->team_id ;?>" />  </td>	
					<td width="200" style="width: 50%; cursor:pointer;" onclick="SximoModal('<?php echo url('sxteam/'.$row->team_id.'/edit');?>','<?php echo $row->team_name ;?>'); return false ;">
						<h6>{{ $row->team_name }}</h6>
						<div style="font-size: 11px; margin-top: 10px;">{!! $row->team_desc !!}</div>
					</td>
					<td class="text-center">
						 Team Leader
						<p class="pt-2 pb-2">
						@foreach($row->team_leader as $leader)
							<img src="{{ asset('uploads/users/'.$leader['avatar']) }}" width="50" class="avatar pr-2 tips" title="{{ $leader['name'] }}" /> 
						@endforeach
					</p>
					</td>
					<td>
						<b> Team Members</b> 
						<div class="pt-2"> 
						@foreach($row->user_ids as $avatar)
							<img src="{{ asset('uploads/users/'.$avatar['avatar']) }}" width="50" class="avatar pr-2 tips" title="{{ $avatar['name'] }}" />
						@endforeach
						</div>
					</td>

				</tr>
			<?php endforeach;?>
			</tbody>
		</table>	

	</div> 
</div>
	<input type="hidden" name="action_task" value="" />
	<?php echo Form::close() ;?>
	@include('ajaxfooter')
</div>	
@if($setting['inline'] =='true') @include('sximo.module.utility.inlinegrid') @endif
@include('sximo.module.template.ajax.javascript')
