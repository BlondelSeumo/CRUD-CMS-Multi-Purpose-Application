<div class="form-ajax-box">
{!! Form::open(array('url'=>'sxteam?return='.$return, 'class'=>'form-vertical validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'sxteamFormAjax')) !!}
<div class="p-3">



					
				{!! Form::hidden('team_id', $row['team_id']) !!}	
				<div class="form-group  " >
					<label for="ipt" class=" control-label "> Team Name    </label>									
					  <input  type='text' name='team_name' id='team_name' value='{{ $row['team_name'] }}' 
	required     class='form-control form-control-sm ' /> 						
				  </div> 				
				  <div class="form-group  " >
					<label for="ipt" class=" control-label "> Leader    </label>									
					  <select name='team_leader' rows='5' id='team_leader' class='select2 ' required  ></select> 						
				  </div> 					
				  <div class="form-group  " >
					<label for="ipt" class=" control-label "> Team Members    </label>									
					  <select name='user_ids[]' multiple rows='5' id='user_ids' class='select2 ' required  ></select> 						
				  </div> 					
				  					
				  <div class="form-group  " >
					<label for="ipt" class=" control-label "> Team Desc    </label>									
					  <textarea name='team_desc' rows='5' id='editor' class='form-control form-control-sm editor '  
	required >{{ $row['team_desc'] }}</textarea> 						
				  </div>

				  <div class="form-group">
				  	<button type="submit" class="btn btn-primary btn-block " name="apply"><i class="fa  fa-check"></i>  {{ Lang::get('core.sb_apply') }} </button>
				  </div>
				  </div>									
						
				


	</div>
	
{!! Form::close() !!}
</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
</style>
			 
<script type="text/javascript">
$(document).ready(function() { 
	
	
		$("#user_ids").jCombo("{!! url('sxteam/comboselect?filter=tb_users:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["user_ids"] }}' });
		
		$("#team_leader").jCombo("{!! url('sxteam/comboselect?filter=tb_users:id:first_name|last_name') !!}",
		{  selected_value : '{{ $row["team_leader"] }}' });
		 	
	 	 
	
	$('.editor').summernote({ height:250});
	
	$('.tips').tooltip();	
	$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
	$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 		
		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxteam/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});
				
	var form = $('#sxteamFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  showRequest,
				success:       showResponse  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

function showRequest()
{
		
}  
function showResponse(data)  {		
	
	if(data.status == 'success')
	{
		ajaxViewClose('#{{ $pageModule }}');
		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data');
		notyMessage(data.message);	
		$('#sximo-modal').modal('hide');	
	} else {
		notyMessageError(data.message);	
		return false;
	}	
}			 

</script>		 