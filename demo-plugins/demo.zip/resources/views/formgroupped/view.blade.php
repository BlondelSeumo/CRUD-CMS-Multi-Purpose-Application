@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small></h2></div>

<div class="toolbar-nav">
	<div class="row">
		<div class="col-md-6 ">
			@if($access['is_add'] ==1)
	   		<a href="{{ url('formgroupped/'.$id.'/edit?return='.$return) }}" class="tips btn btn-default btn-sm  " title="{{ __('core.btn_edit') }}"><i class="fa  fa-pencil"></i></a>
			@endif
			<a href="{{ url('formgroupped?return='.$return) }}" class="tips btn btn-default  btn-sm  " title="{{ __('core.btn_back') }}"><i class="fa  fa-times"></i></a>		
		</div>
		<div class="col-md-6 text-right">			
	   		<a href="{{ ($prevnext['prev'] != '' ? url('formgroupped/'.$prevnext['prev'].'?return='.$return ) : '#') }}" class="tips btn btn-default  btn-sm"><i class="fa fa-arrow-left"></i>  </a>	
			<a href="{{ ($prevnext['next'] != '' ? url('formgroupped/'.$prevnext['next'].'?return='.$return ) : '#') }}" class="tips btn btn-default btn-sm "> <i class="fa fa-arrow-right"></i>  </a>					
		</div>	

		
		
	</div>
</div>
<div class="card">		
	<div class="card-body">

	<div class="table-responsive">
		<table class="table  table-bordered " >
			<tbody>	
		
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Id', (isset($fields['id']['language'])? $fields['id']['language'] : array())) }}</td>
						<td>{{ $row->id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Text', (isset($fields['input_text']['language'])? $fields['input_text']['language'] : array())) }}</td>
						<td>{{ $row->input_text}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Radio', (isset($fields['input_radio']['language'])? $fields['input_radio']['language'] : array())) }}</td>
						<td>{{ $row->input_radio}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Date', (isset($fields['input_date']['language'])? $fields['input_date']['language'] : array())) }}</td>
						<td>{{ $row->input_date}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Datetime', (isset($fields['input_datetime']['language'])? $fields['input_datetime']['language'] : array())) }}</td>
						<td>{{ $row->input_datetime}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Checkbox', (isset($fields['input_checkbox']['language'])? $fields['input_checkbox']['language'] : array())) }}</td>
						<td>{{ $row->input_checkbox}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Textarea', (isset($fields['input_textarea']['language'])? $fields['input_textarea']['language'] : array())) }}</td>
						<td>{{ $row->input_textarea}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Textareaeditor', (isset($fields['input_textareaeditor']['language'])? $fields['input_textareaeditor']['language'] : array())) }}</td>
						<td>{{ $row->input_textareaeditor}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Select', (isset($fields['input_select']['language'])? $fields['input_select']['language'] : array())) }}</td>
						<td>{{ $row->input_select}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Selectmulti', (isset($fields['input_selectmulti']['language'])? $fields['input_selectmulti']['language'] : array())) }}</td>
						<td>{{ $row->input_selectmulti}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input File', (isset($fields['input_file']['language'])? $fields['input_file']['language'] : array())) }}</td>
						<td>{{ $row->input_file}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Input Filemulti', (isset($fields['input_filemulti']['language'])? $fields['input_filemulti']['language'] : array())) }}</td>
						<td>{{ $row->input_filemulti}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Country Id', (isset($fields['country_id']['language'])? $fields['country_id']['language'] : array())) }}</td>
						<td>{{ $row->country_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('State Id', (isset($fields['state_id']['language'])? $fields['state_id']['language'] : array())) }}</td>
						<td>{{ $row->state_id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('City Id', (isset($fields['city_id']['language'])? $fields['city_id']['language'] : array())) }}</td>
						<td>{{ $row->city_id}} </td>
						
					</tr>
				
			</tbody>	
		</table>   

	 	

	</div>
	</div>	

</div>
@stop
