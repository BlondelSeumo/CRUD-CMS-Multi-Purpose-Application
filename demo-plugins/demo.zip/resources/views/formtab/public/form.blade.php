

		 {!! Form::open(array('url'=>'formtab', 'class'=>'form-vertical','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<ul class="nav nav-tabs form-tab"><li class=" nav-item "><a href="#Basic" data-toggle="tab" class="nav-link active">Basic</a></li>
				<li class=" nav-item "><a href="#Upload" data-toggle="tab" class="nav-link ">Upload</a></li>
				<li class=" nav-item "><a href="#Select" data-toggle="tab" class="nav-link ">Select</a></li>
				</ul><div class="tab-content"><div class="tab-pane m-t active" id="Basic"> 
				{!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Text  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='input_text' id='input_text' value='{{ $row['input_text'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Radio  <span class="asterix"> * </span>  </label>									
										  
					
					<input type='radio' name='input_radio' value ='1' required @if($row['input_radio'] == '1') checked="checked" @endif class='filled-in' id='input_radio-0'> <label for='input_radio-0'>Option I </label>
					
					<input type='radio' name='input_radio' value ='2' required @if($row['input_radio'] == '2') checked="checked" @endif class='filled-in' id='input_radio-1'> <label for='input_radio-1'>Option II </label>
					
					<input type='radio' name='input_radio' value ='3' required @if($row['input_radio'] == '3') checked="checked" @endif class='filled-in' id='input_radio-2'> <label for='input_radio-2'>Option III </label> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Date  <span class="asterix"> * </span>  </label>									
										  
				
					{!! Form::text('input_date', $row['input_date'],array('class'=>'form-control form-control-sm date')) !!} 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Datetime  <span class="asterix"> * </span>  </label>									
										  
					{!! Form::text('input_datetime', $row['input_datetime'],array('class'=>'form-control form-control-sm datetime')) !!}
				 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Checkbox  <span class="asterix"> * </span>  </label>									
										  <?php $input_checkbox = explode(",",$row['input_checkbox']); ?>
					  
					<input type='checkbox' name='input_checkbox[]' value ='1' required  class=' filled-in' id='input_checkbox-0'
					@if(in_array('1',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-0'> Value I </label> 
					  
					<input type='checkbox' name='input_checkbox[]' value ='2' required  class=' filled-in' id='input_checkbox-1'
					@if(in_array('2',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-1'> Value II </label> 
					  
					<input type='checkbox' name='input_checkbox[]' value ='3' required  class=' filled-in' id='input_checkbox-2'
					@if(in_array('3',$input_checkbox))checked @endif 
					 /> <label for='input_checkbox-2'> Value III </label>  						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Textarea  <span class="asterix"> * </span>  </label>									
										  <textarea name='input_textarea' rows='5' id='input_textarea' class='form-control form-control-sm '  
				         required  >{{ $row['input_textarea'] }}</textarea> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Textareaeditor  <span class="asterix"> * </span>  </label>									
										  <textarea name='input_textareaeditor' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['input_textareaeditor'] }}</textarea> 						
									  </div> 
				</div>
				
				<div class="tab-pane m-t " id="Upload"> 
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input File  <span class="asterix"> * </span>  </label>									
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="input_file" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="input_file-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["input_file"],"/uploads/images/") !!}
						</div>
					 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Filemulti  <span class="asterix"> * </span>  </label>									
										  
					<a href="javascript:void(0)" class="btn btn-xs btn-primary pull-right" onclick="addMoreFiles('input_filemulti')"><i class="fa fa-plus"></i></a>
					<div class="input_filemultiUpl multipleUpl">	
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-copy"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="input_filemulti[]" class="upload"       />
						</div>		
					</div>
					<ul class="uploadedLists " >
					<?php $cr= 0; 
					$row['input_filemulti'] = explode(",",$row['input_filemulti']);
					?>
					@foreach($row['input_filemulti'] as $files)
						@if(file_exists('./uploads/images/'.$files) && $files !='')
						<li id="cr-<?php echo $cr;?>" class="">							
							<a href="{{ url('/uploads/images//'.$files) }}" target="_blank" >
							{!! SiteHelpers::showUploadedFile( $files ,"/uploads/images/",100) !!}
							</a> 
							<span class="pull-right removeMultiFiles" rel="cr-<?php echo $cr;?>" url="/uploads/images/{{$files}}">
							<i class="fa fa-trash-o  btn btn-xs btn-danger"></i></span>
							<input type="hidden" name="currinput_filemulti[]" value="{{ $files }}"/>
							<?php ++$cr;?>
						</li>
						@endif
					
					@endforeach
					</ul>
					 						
									  </div> 
				</div>
				
				<div class="tab-pane m-t " id="Select"> 
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Select  <span class="asterix"> * </span>  </label>									
										  
					<?php $input_select = explode(',',$row['input_select']);
					$input_select_opt = array( '1' => 'Value I' ,  '2' => 'Value II' ,  '3' => 'Value III' , ); ?>
					<select name='input_select' rows='5' required  class='select2 '  > 
						<?php 
						foreach($input_select_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['input_select'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Input Selectmulti  <span class="asterix"> * </span>  </label>									
										  <select name='input_selectmulti[]' multiple rows='5' id='input_selectmulti' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Country Id  <span class="asterix"> * </span>  </label>									
										  <select name='country_id' rows='5' id='country_id' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> State Id  <span class="asterix"> * </span>  </label>									
										  <select name='state_id' rows='5' id='state_id' class='select2 ' required  ></select> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> City Id  <span class="asterix"> * </span>  </label>									
										  <select name='city_id' rows='5' id='city_id' class='select2 ' required  ></select> 						
									  </div> 
				</div>
				
				

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#input_selectmulti").jCombo("{!! url('formtab/comboselect?filter=products:productCode:productName') !!}",
		{  selected_value : '{{ $row["input_selectmulti"] }}' });
		
		$("#country_id").jCombo("{!! url('formtab/comboselect?filter=countries:country_id:country_name') !!}",
		{  selected_value : '{{ $row["country_id"] }}' });
		
		$("#state_id").jCombo("{!! url('formtab/comboselect?filter=states:state_id:state_name') !!}&parent=country_id:",
		{  parent: '#country_id', selected_value : '{{ $row["state_id"] }}' });
		
		$("#city_id").jCombo("{!! url('formtab/comboselect?filter=cities:city_id:city_name') !!}",
		{  selected_value : '{{ $row["city_id"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
