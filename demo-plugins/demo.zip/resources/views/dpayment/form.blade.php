<div class="form-ajax-box">
{!! Form::open(array('url'=>'dpayment?return='.$return, 'class'=>'form-horizontal form-material sximo-form validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'dpaymentFormAjax')) !!}

	<div class="toolbar-nav">	
		<div class="row">	
			
			<div class="col-md-6">
							
			</div>
			<div class="col-sm-6 text-right">	
				<button type="submit" class="btn btn-sm  btn-primary " name="apply"> {{ Lang::get('core.sb_apply') }} </button>
				<button type="submit" class="btn btn-sm btn-success" name="save">  {{ Lang::get('core.sb_save') }} </button>
				<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm btn-danger  " title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>	
			</div>	
					
		</div>
	</div>	
		<div class="row">

	
	<div class="col-md-12">
						<fieldset><legend> Payments ( DataTable )</legend>
				{!! Form::hidden('id', $row['id']) !!}					
									  <div class="form-group row  " >
										<label for="Customer Name" class=" control-label col-md-4 text-left"> Customer Name <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <select name='customerNumber' rows='5' id='customerNumber' class='select2 ' required  ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Check Number" class=" control-label col-md-4 text-left"> Check Number <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='checkNumber' id='checkNumber' value='{{ $row['checkNumber'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Payment Date" class=" control-label col-md-4 text-left"> Payment Date <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  
				
					{!! Form::text('paymentDate', $row['paymentDate'],array('class'=>'form-control form-control-sm date')) !!} 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Amount" class=" control-label col-md-4 text-left"> Amount <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='amount' id='amount' value='{{ $row['amount'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>									
		
	<input type="hidden" name="action_task" value="save" />				
				


	

</div>		
{!! Form::close() !!}
</div>
@include('sximo.module.template.ajax.formjavascript')

<script type="text/javascript">
$(document).ready(function() { 
	
		$("#customerNumber").jCombo("{!! url('dpayment/comboselect?filter=customers:customerNumber:customerName') !!}",
		{  selected_value : '{{ $row["customerNumber"] }}' });
		 
	
	 
				
	var form = $('#dpaymentFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  function(){
				},
				success: function(data) {
					if(data.status == 'success')
					{
						ajaxViewClose('#{{ $pageModule }}');
						var table = $('#dpaymentTable').DataTable();
						table.ajax.reload();
						notyMessage(data.message);	
						$('#sximo-modal').modal('hide');	
					} else {
						notyMessageError(data.message);	
						return false;
					}
				}  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

</script>		 