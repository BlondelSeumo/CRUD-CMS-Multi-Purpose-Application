

	{!! Form::open(array('url'=>'sxproject?return='.$return, 'class'=>'form-vertical validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}



	<div class="p-5">
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	
						
				{!! Form::hidden('project_id', $row['project_id']) !!}	
				<div class="col-md-6">				
				  <div class="form-group  " >
					<label for="ipt" class=" control-label "> Project Owner    </label>									
					  <select name='customer_id' rows='5' id='customer_id' class='select2 ' required  ></select> 						
				  </div> 			
				</div>  
				<div class="col-md-6">	

				  	<div class="form-group  " >
						<label for="ipt" class=" control-label "> Assign To Team    </label>									
					  <select name='team_id' rows='5' id='team_id' class='select2 ' required  ></select> 						
					</div> 			
				</div>

			</div>
			<div class="row">
				<div class="col-md-12">					  		
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Project Name    </label>									
										  <input  type='text' name='project_name' id='project_name' value='{{ $row['project_name'] }}' 
						required     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Description    </label>									
										  <textarea name='description' rows='5' id='editor' class='form-control form-control-sm editor '  
						required >{{ $row['description'] }}</textarea> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Progress    </label>									
										  <input  type='text' name='progress' id='progress' value='{{ $row['progress'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 			
				</div>	
			</div>	
			<div class="row">
				<div class="col-md-6">						  		
					<div class="form-group  " >
					<label for="ipt" class=" control-label "> Start Date    </label>									
					  
					<div class="input-group input-group-sm m-b" style="width:150px !important;">
						{!! Form::text('start_date', $row['start_date'],array('class'=>'form-control form-control-sm date')) !!}
						<div class="input-group-append">
						 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
						 </div>
					</div> 						
				  </div> 	
				</div>
				<div class="col-md-6">  				
				  <div class="form-group  " >
					<label for="ipt" class=" control-label "> End Date    </label>									
					  
					<div class="input-group input-group-sm m-b" style="width:150px !important;">
						{!! Form::text('end_date', $row['end_date'],array('class'=>'form-control form-control-sm date')) !!}
						<div class="input-group-append">
						 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
						 </div>
					</div> 						
				  </div> 

				</div>
			</div>	
	
		</div>
		<div class="row">
			<div class="col-md-12">
				<button class="btn btn-primary btn-block"> Save Change(s)</button>
			</div>
		</div>		
		
		<input type="hidden" name="action_task" value="save" />
		
		</div>
		
	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$('.editor').summernote({ height: 250});		
		$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
		$("#customer_id").jCombo("{!! url('sxproject/comboselect?filter=sx_customers:customer_id:name') !!}",
		{  selected_value : '{{ $row["customer_id"] }}' });
		
		$("#team_id").jCombo("{!! url('sxproject/comboselect?filter=sx_teams:team_id:team_name') !!}",
		{  selected_value : '{{ $row["team_id"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxproject/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
