@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>
<div class="toolbar-nav bg-grey" >   
	<div class="row">
		<div class="col-md-8 ">
			<div class="input-group ">
		      <div class="input-group-prepend">
		      	<a href="{{ url('sxtask?view=list')}}" class="btn btn-sm btn-default tips" title="table view" ><i class="fa fa-table"></i></a>
		      	<a href="{{ url('sxtask?view=kanban')}}" class="btn btn-sm btn-default tips" title="Block View"><i class="fa fa-reorder"></i></a>
		        <button type="button" class="btn btn-default btn-sm " style="text-transform: none !important" 
		        onclick="SximoModal('{{ url($pageModule."/search") }}','Advance Search'); " ><i class="fa fa-reload"></i> Summary </button>
		      </div><!-- /btn-group -->
		     </div>
			
		</div> 
		<div class="col-md-4" > 	
			

			<div class="btn-group  pull-right">
				@if($access['is_add'] ==1)
			<a href="{{ url('sxproject/create?return='.$return) }}" class="btn  btn-sm"  onclick="SximoModal(this.href, 'New Project'); return false ;" 
				title="{{ __('core.btn_create') }}"><i class=" fa fa-plus "></i> Add New </a>
			@endif
				<button type="button" class="btn btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bars"></i> Bulk Action </button>
		        <ul class="dropdown-menu">
		        @if($access['is_remove'] ==1)
					 <li class="nav-item"><a href="javascript://ajax"  onclick="SximoDelete();" class="nav-link tips" title="{{ __('core.btn_remove') }}">
					Remove Selected </a></li>
				@endif 
				@if($access['is_add'] ==1)
					<li class="nav-item"><a href="javascript://ajax" class=" copy nav-link " title="Copy" > Copy selected</a></li>
					<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule .'/import?return='.$return) }}" onclick="SximoModal(this.href, 'Import CSV'); return false;" class="nav-link "> Import CSV</a></li>

					
				@endif
				<div class="dropdown-divider"></div>
		        @if($access['is_excel'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=excel&return='.$return) }}" class="nav-link "> Export Excel </a></li>	
				@endif
				@if($access['is_csv'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=csv&return='.$return) }}" class="nav-link "> Export CSV </a></li>	
				@endif
				@if($access['is_pdf'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=pdf&return='.$return) }}" class="nav-link "> Export PDF </a></li>	
				@endif
				@if($access['is_print'] ==1)
					<li class="nav-item"><a href="{{ url( $pageModule .'/export?do=print&return='.$return) }}" class="nav-link "> Print Document </a></li>	
				@endif
				<div class="dropdown-divider"></div>
					<li class="nav-item"><a href="{{ url($pageModule) }}"  class="nav-link "> Clear Search </a></li>
		          	
		        
		          
		        </ul>
		    </div>    
		</div>
		   
	</div>	

</div>	
<div class="card">
	<div class="">

			<!-- Table Grid -->
			
 			{!! Form::open(array('url'=>'sxproject?'.$return, 'class'=>'form-horizontal m-t' ,'id' =>'SximoTable' )) !!}

 			<table class="table table-striped">
 				<thead>
 					<tr>
 						<th colspan="5"> All Projects </th>
 					</tr>
 				</thead>
 				<tbody>
 					 @foreach ($rowData as $row)
 					<tr >
 						<td  style="cursor: pointer;" onclick="window.location.href = '{{ url('sxproject/'.$row->project_id) }}'">
 							<i class="fa fa-ellipsis-v" style="margin-right:10px; "></i>
 							<span style="padding-left: 20px;"> 
	 							<h5 style="margin-bottom: 0;"> {{ $row->project_name }}	</h5>
 								<a href="#"><small> Owner : {{ $row->name }} </small></a>
 							</span>	

 						</td>
 						<td width="" style="width: 20%;">
 							<small><b> Progress : </b></small> <br />
 							<div class="progress progress-sm">
							  <div class="progress-bar bg-success" role="progressbar" style="width: {{ $row->progress }}%" aria-valuenow="{{ $row->progress }}" aria-valuemin="0" aria-valuemax="100"></div>
							</div>

 						</td>
 						<td>
 							<small> Milestone / Tasks / Checklists </small> <br />
 							<badge class="badge badge-primary"> {{ $row->milestone['milestone']}} /  {{ $row->milestone['tasks']}}  /  {{ $row->milestone['todo']}}</badge>
 						</td>
 						<td> 
 							<small class="text-success"> Start : {{ $row->start_date }} </small> <br />
 							<small class="text-danger"> End :  {{ $row->end_date }} </small>
 						</td>
 						<td>
 							<a href="{{ url('sxproject/'.$row->project_id)}}/edit" class="btn btn-sm btn-default"  onclick="SximoModal(this.href, 'Edit Project'); return false ;" ><i class="fa fa-pencil"></i> Edit </a>
 						</td>
 						
 					</tr>
 						<tr class="project_list">

 							<td colspan="5">
 								<div class="pl-4"> 	
 									<h6> Description : </h6>
 									{!! $row->description !!}
 								</div>
 								<div class="pl-4 pt-2 pb-2"> 
 									<div class="row">
 										<div class="col-md-6">
		 									Team :  <b> {{ $row->team_name }} </b> <br />
				 							@foreach($row->user_ids as $avatar)
			 								<img src="{{ asset('uploads/users/'.$avatar['avatar']) }}" width="30" class="avatar tips" title="{{ $avatar['name']}}" />
			 								@endforeach
			 							</div>	
			 							<div class="col-md-6">

			 								<div class="pt-3 btn-group pull-right btn-outline">
				 								<a href="{{ url('sxtask?p='.$row->project_id)}}" class="btn btn-sm btn-default "><i class="fa fa-list"></i> Tasks </a>
				 								<a href="#" onclick="notyMessageError(' Please install docs module'); " class="btn btn-sm btn-default"><i class="fa fa-file"></i> Docs  </a>
				 								
				 								<a href="#" class="btn btn-sm btn-default" onclick="notyMessageError(' Please install Issues module'); " ><i class="fa fa-clock-o"></i> Issue Tracker </a>
				 								
				 								<div class="btn-group">
													  <button class="btn btn-default btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													    Utilities
													  </button>
													  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
													    <a class="dropdown-item" href="#" onclick="notyMessageError(' Please install Invoice module'); " > Invoice </a>
													    <a class="dropdown-item" href="#"> Files </a>
													    <a class="dropdown-item" href="#" onclick="notyMessageError(' Please install Activities module'); " > Activities </a>
													  </div>
													</div>

				 								</div>

				 								

				 							</div>

			 							</div>	
			 						</div>	
 							</div>
 							</td>
 							
 						</tr>
 					@endforeach
 				</tbody>

 			</table>
 	</div>

			<input type="hidden" name="action_task" value="" />
			
			{!! Form::close() !!}
			
			
			<!-- End Table Grid -->

</div>
@include('footer')
<script>
$(document).ready(function(){
	$('.copy').click(function() {
		var total = $('input[class="ids"]:checkbox:checked').length;
		if(confirm('are u sure Copy selected rows ?'))
		{
			$('input[name="action_task"]').val('copy');
			$('#SximoTable').submit();// do the rest here	
		}
	})	
	
});	
</script>	
<style type="text/css">
	.progress {
		height: 10px;
	}
	tr.project_list td {
		border-top: none !important ;
	}
	a.btn-default , .btn-default{
		color: #333 !important;
	} 
</style>
	
@stop
