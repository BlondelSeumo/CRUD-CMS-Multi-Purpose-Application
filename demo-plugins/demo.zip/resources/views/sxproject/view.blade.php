@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $row->project_name }} <small> {{ $pageNote }} </small></h2></div>
	<div class="toolbar-nav ">
		<ul class="nav nav-tabs" class="p-2">
			<li class="nav-item">
				 <a class="nav-link active" href="{{ url('sximo/config/')}}"> Overview </a>
			</li>
			<li class="nav-item"> <a href="#" class="nav-link"><i class="fa fa-calendar-check-o"></i> Tasks </a></li>
			<li class="nav-item"> <a href="#" class="nav-link"><i class="fa fa-file-o"></i> Docs / Wiki  </a></li>
			<li class="nav-item"> <a href="#" class="nav-link"><i class="fa fa-comment"></i> Discussion  </a></li>
			<li class="nav-item"> <a href="#" class="nav-link"><i class="fa fa-clock-o"></i> Activities </a></li>
			<li class="nav-item"> <a href="#" class="nav-link"><i class="fa fa-files-o"></i> Files </a></li>
      
		</ul>
	</div>
<div class="p-3">		



	<div class="row mt-2">
		
		<div class="col-md-9">
			<fieldset>
				<legend> {{ $row->project_name }}</legend>
				<h6> Project Description </h6>
				<div class="pt-3">
					{!! $row->description !!}
				</div>
			</fieldset>

			<fieldset>
				<legend> Summary  </legend>
				
			</fieldset>
			<fieldset>
				<legend> Team Performance </legend>
				
			</fieldset>
			
		</div>

		<div class="col-md-3">
      <fieldset>
        <legend>  Project Owner </legend>

      </fieldset>
			<fieldset>
				<legend>  Project Settings </legend>
			<table class="table">
			<tbody>
              <tr class="project-overview-customer">
                  <td class="bold">Customer</td>
                  <td>
                      <a href="https://www.perfexcrm.com/demo/admin/clients/client/1">
                        Schmitt LLC                      </a>
                  </td>
              </tr>
                              <tr class="project-overview-billing">
                  <td class="bold">Billing Type</td>
                  <td>
                     Task Hours                 </td>
                            </tr><tr class="project-overview-status">
            <td class="bold">Status</td>
            <td>In Progress</td>
         </tr>
         <tr class="project-overview-date-created">
            <td class="bold">Date Created</td>
            <td>01/12/2019</td>
         </tr>
         <tr class="project-overview-start-date">
            <td class="bold">Start Date</td>
            <td>01/12/2019</td>
         </tr>
                  <tr class="project-overview-deadline">
            <td class="bold">Deadline</td>
            <td>01/02/2020</td>
         </tr>
                                             <tr class="project-overview-total-logged-hours">
            <td class="bold">Total Logged Hours</td>
            <td>04:06</td>
         </tr>
                        </tbody> </table>
			
                    </fieldset>

		</div>
	</div>	

	
	 	

	</div>

</div>
<style type="text/css">
	.nav-pills

    {
       align-items: center;

    }
    .nav-pills > li
    {
    float: none;
     text-align: center;
    }
    .nav > li 
    {
    display: inline-block;
    }
</style>
@stop
