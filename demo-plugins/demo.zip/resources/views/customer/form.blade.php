@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'customer?return='.$return, 'class'=>'form-horizontal form-material validated sximo-form','files' => true ,'id'=> 'FormTable' )) !!}
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6 " >
				 
			</div>
			<div class="col-md-6  text-right " >
				<div class="submitted-button">
					<button name="apply" class="tips btn btn-sm btn-primary  "  title="{{ __('core.btn_back') }}" > {{ __('core.sb_apply') }} </button>
					<button name="save" class="tips btn btn-sm btn-success "  id="saved-button" title="{{ __('core.btn_back') }}" > {{ __('core.sb_save') }} </button> 
					<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-warning  btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>
				</div>	
			</div>
			
		</div>
	</div>	


	
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	<div class="col-md-12">
						<fieldset><legend> Info</legend>
				{!! Form::hidden('customerNumber', $row['customerNumber']) !!}					
									  <div class="form-group row  " >
										<label for="CustomerName" class=" control-label col-md-4 text-left"> CustomerName </label>
										<div class="col-md-8">
										  <input  type='text' name='customerName' id='customerName' value='{{ $row['customerName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="LastName" class=" control-label col-md-4 text-left"> LastName </label>
										<div class="col-md-8">
										  <input  type='text' name='contactLastName' id='contactLastName' value='{{ $row['contactLastName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="FirstName" class=" control-label col-md-4 text-left"> FirstName </label>
										<div class="col-md-8">
										  <input  type='text' name='contactFirstName' id='contactFirstName' value='{{ $row['contactFirstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Sales" class=" control-label col-md-4 text-left"> Sales </label>
										<div class="col-md-8">
										  <input  type='text' name='salesRepEmployeeNumber' id='salesRepEmployeeNumber' value='{{ $row['salesRepEmployeeNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="CreditLimit" class=" control-label col-md-4 text-left"> CreditLimit </label>
										<div class="col-md-8">
										  <input  type='text' name='creditLimit' id='creditLimit' value='{{ $row['creditLimit'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 
				</div>
				
				<div class="col-md-12">
						<fieldset><legend> Address</legend>
									
									  <div class="form-group row  " >
										<label for="Phone" class=" control-label col-md-4 text-left"> Phone </label>
										<div class="col-md-8">
										  <input  type='text' name='phone' id='phone' value='{{ $row['phone'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine 1" class=" control-label col-md-4 text-left"> AddressLine 1 </label>
										<div class="col-md-8">
										  <input  type='text' name='addressLine1' id='addressLine1' value='{{ $row['addressLine1'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine 2" class=" control-label col-md-4 text-left"> AddressLine 2 </label>
										<div class="col-md-8">
										  <input  type='text' name='addressLine2' id='addressLine2' value='{{ $row['addressLine2'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="State" class=" control-label col-md-4 text-left"> State </label>
										<div class="col-md-8">
										  <input  type='text' name='state' id='state' value='{{ $row['state'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Posta lCode" class=" control-label col-md-4 text-left"> Posta lCode </label>
										<div class="col-md-8">
										  <input  type='text' name='postalCode' id='postalCode' value='{{ $row['postalCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Country" class=" control-label col-md-4 text-left"> Country </label>
										<div class="col-md-8">
										  <select name='country' rows='5' id='country' class='select2 '   ></select> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="City" class=" control-label col-md-4 text-left"> City </label>
										<div class="col-md-8">
										  <input  type='text' name='city' id='city' value='{{ $row['city'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 
				</div>
				
				
	
		</div>
		
		<input type="hidden" name="action_task" value="save" />
		
		
				


	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#country").jCombo("{!! url('customer/comboselect?filter=countries:country_name:country_name') !!}",
		{  selected_value : '{{ $row["country"] }}' });
		 	
		 	 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("customer/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop