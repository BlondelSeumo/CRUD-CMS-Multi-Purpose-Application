
	<div class="toolbar-nav">
		<div class="row">
			<div class="col-md-6" >
					
			</div>
			<div class="col-md-6 text-right" >
		   		<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm  " title="{{ __('core.btn_back') }}"><i class="fa  fa-times"></i></a>		
			</div>	

			
		</div>
	</div>	
	<div class="table-container" style="overflow-x: hidden;">
		<div class="row" style=" background-color: #fff; ">

	<div class="col-md-9" style="background-color: #f9f9fc;">
		<div class="p-4">

		<div class="card">
			
			<div class="card-body p-5">
				<div class="row">
					<div class="col-md-6">
						@if(file_exists(public_path().'/uploads/images/'.config('sximo')['cnf_logo']) && config('sximo')['cnf_logo'] !='')
			              <img src="{{ asset('uploads/images/'.config('sximo')['cnf_logo'])}}" alt="{{ config('sximo')['cnf_appname'] }}" width="100" />
			              @else
			              <img src="{{ asset('uploads/logo.png')}}" alt="{{ config('sximo')['cnf_appname'] }}"  width="100" />
			              @endif

					</div>
					<div class="col-md-6 text-right">
						<h6>Perfex INC </h6>
						172 Ivy Club Gottliebfurt <br />
						New Heaven<br />
						Canada [CA] 2364<br />

					</div>
				</div>
				<hr />
				<div class="row mt-3">
					<div class="col-md-4">
						<h6>Bill To: </h6>
						O'Conner-Schmitt<br />
						44248 Spencer Rest<br />
						Port Kristofer Minnesota<br />
						PM 89891-0409<br />
						VAT Number: AT U19374851

					</div>
					<div class="col-md-4">
						<h6> Shipp To: </h6>
						O'Conner-Schmitt<br />
						44248 Spencer Rest<br />
						Port Kristofer Minnesota<br />
						PM 89891-0409<br />
						VAT Number: AT U19374851

					</div>
					<div class="col-md-4  text-right">
						<h5> Invoice #{{ $row->number }} </h5>
						<p>
							<b> Date :  </b> {{ $row->date }} <br />
							<b> Due Date : </b> {{ $row->duedate }}

						</p>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-12">

						<table class="table preview-invoice">
							<thead>
								<tr>
									<th width="50%" style="width: 50%;"> Description </th>
									<th class="text-right"> Qty </th>
									<th class="text-right"> Price </th>
									
									<th class="text-right"> Amount </th>
								</tr>
							</thead>
							<tbody>
							@foreach($items as $item)
								<tr >
									<td class="border-top"> {{ $item->item_name }}</td>
									<td class="text-right border-top">$ {{ $item->qty }}</td>
									<td class="text-right border-top">$ {{ $item->amount }}</td>
									<td class="text-right border-top" >$ {{ number_format($item->qty * $item->amount,0) }} </td>
									
								</tr>
							@endforeach
								<tr>
									<td colspan="4" style="height: 50px; border-top: solid 1px #eee !important;"></td>
								</tr>	

								<tr>
									<td colspan="2"></td>
									<td class="text-right"><b>Sub Total</b></td>
									<td class="text-right"> </td>
								</tr>	
								<tr>
									<td colspan="2"></td>
									<td class="text-right"> <b>Tax</b> </td>
									<td class="text-right"> $ {{ $row->tax }}
									</td>
								</tr>
								<tr>
									<td colspan="2"></td>
									<td class="text-right"> <b> Discount </b></td>
									<td class="text-right"> $ {{ $row->discount }} </td>
								</tr>
								<tr>
									<td colspan="2"></td>
									<td class="text-right"> <b> Grand Total </b></td>
									<td class="text-right"> $ {{ $row->total }}</td>
								</tr>

							</tbody>
						</table>
					</div>
				</div>

				<div class="row mt-3">
					<div class="col-md-12">
						<b> Note : </b> <br /> 
						<p>{!! $row->note !!} </p>
						<hr />
						<b> Terms & Conditions </b> 
						<p>{!! $row->terms !!} </p>
					</div>
				</div>

			</div>
		</div>	
	</div>
	</div>
	
	<div class="col-md-3">
		<div class="p-4" >
			<h4> Payments </h4>
			<div class="progress progress-sm">
			  <div class="progress-bar bg-success" role="progressbar" style="width:25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
			</div>
			<p> $2,322 of $3,076 </p>

			<div>
				<ul class="invoice-log">
					<li> <b> Invoice Created </b> <br />{{ date("m/d/Y", strtotime( $row->created_at) ) }} –{{ date("H:i" , strtotime( $row->created_at))}} </li>
					<li> <b> Invoice Sent </b> <br />{{ date("m/d/Y", strtotime( $row->sent_at) ) }} –{{ date("H:i" , strtotime( $row->sent_at))}}  </li>
					
					
				</ul>	
			</div>

		</div>	
	</div>

		 	
<style type="text/css">
	table.preview-invoice tr td{
		border:none !important;

	}
	table.preview-invoice tr td.border-top{
		border-top:solid 1px #eee !important;

	}
	ul.invoice-log {
		margin: 0;
		padding: 0;
		list-style: none
	}
	ul.invoice-log li {
		padding: 10px 0 10px 40px;
	}	
	ul.invoice-log li b{
		font-size: 14px;
	}
	.progress {
		height: 10px;
	}
</style>

	</div>	
</div>

