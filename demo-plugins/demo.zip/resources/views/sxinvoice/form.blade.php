<div class="form-ajax-box">
{!! Form::open(array('url'=>'sxinvoice?return='.$return, 'class'=>'form-vertical validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'sxinvoiceFormAjax')) !!}

	<div class="toolbar-nav">	
		<div class="row">	
			<div class="col-sm-6 ">	
				<button type="submit" class="btn btn-default btn-sm " name="apply"><i class="fa  fa-check"></i>  {{ Lang::get('core.sb_apply') }} </button>
				<button type="submit" class="btn btn-default btn-sm " name="save"><i class="fa  fa-paste"></i>  SEND INVOICE </button>
			</div>	
			<div class="col-md-6 text-right">
				<a href="javascript://ajax" onclick="ajaxViewClose('#{{ $pageModule }}')" class="tips btn btn-sm  " title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a>				
			</div>
					
		</div>
	</div>	
		<div class="card">
			<div class="card-body">
			<fieldset>
				<legend> Invoice Details </legend>
				
				{!! Form::hidden('invoice_id', $row['invoice_id']) !!}
			<div class="row">
				<div class="col-md-6">
					<div class="form-group   " >
						<label for="Customer Id" class=" control-label "> Customer </label>
						<div>
						  <select name='customer_id' rows='5' id='customer_id' class='select2 ' required   ></select> 
						 </div> 
					  </div>
					  <div class="form-group   " >
						<label for="Customer Id" class=" control-label "> Related Project </label>
						<div>
						  <select name='project_id' rows='5' id='project_id' class='select2 '   ></select> 
						  <div class="text-mute"><small> If relation to project </small></div>
						 </div> 

					  </div>

						      

				</div>
				<div class="col-md-6">

					<div class="form-group   " >
						<label for="Customer Id" class=" control-label "> Invoice Number </label>
						<div>
							
							 	<input  type='text' name='number' id='number' value='{{ $row['number'] }}'  class='form-control form-control-sm ' required /> 	
								
						 </div> 
					  </div>
					 <div class="row">
						<div class="form-group col-md-6   " >
							<label for="Customer Id" class=" control-label "> Date </label>
							<div>
							  	<div class="input-group input-group-sm m-b" >
									{!! Form::text('date', $row['date'],array('class'=>'form-control form-control-sm date')) !!}
									<div class="input-group-append">
									 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
									 </div>
								</div> 
							 </div> 
						  </div>  

						<div class="form-group   col-md-6 " >
							<label for="Customer Id" class=" control-label "> Due Date </label>
							<div>
									<div class="input-group input-group-sm m-b" >
										{!! Form::text('duedate', $row['duedate'],array('class'=>'form-control form-control-sm date' ,'required'=> true)) !!}
										<div class="input-group-append">
										 	<div class="input-group-text"><i class="fa fa-calendar"></i></span></div>
										 </div>
									</div>
											  
							 </div> 
						  </div> 
					</div>
					

				</div>

			</div>
		</fieldset>
	</div>
		<fieldset>
			<legend> Invoice Items </legend>
			<div class="row">
				
					<table class="table table-invoice">
							<thead>
								<tr>
									<th width="50%" style="width: 50%;"> Item </th>
									<th> Qty </th>
									<th> Price </th>
									
									<th> Amount </th>
									<th></th>

								</tr>
							</thead>
							<tbody>
								@if(count($items) >=1)
									@foreach($items as $item)
									<tr class="clone clonedInput">
										<td><input type="text" class="form-control form-control-sm" name="item_name[]" placeholder="Item Name  ... " required="true" value="{{ $item->item_name }}"></td>
										<td><input type="text" class="form-control form-control-sm text-right"  required="true" name="qty[]" value="{{ $item->qty }}"></td>
										<td><input type="text" class="form-control form-control-sm text-right"  required="true" name="amount[]" value="{{ $item->amount }}"></td>
										<td>
											<div class="input-group">
												<div class="input-group-prepend">
												 	<div class="input-group-text"> $</div>
												 </div>
															<input type="text" class="form-control form-control-sm text-right"  readonly="1" name="total[]" > 
											</div>
										</td>
										<td>

											<a onclick=" $(this).parents('.clonedInput').remove(); calculateSum(); return false" href="javascript:void(0)" class="remove btn btn-xs btn-danger">-</a>
									 	
										</td>
									</tr>
									@endforeach
								@else
								<tr class="clone clonedInput">
									<td><input type="text" class="form-control form-control-sm" name="item_name[]" placeholder="Item Name  ... " required="true"></td>
									<td><input type="text" class="form-control form-control-sm text-right"  required="true" name="qty[]"></td>
									<td><input type="text" class="form-control form-control-sm text-right"  required="true" name="amount[]"></td>
									<td>
										<div class="input-group">
											<div class="input-group-prepend">
											 	<div class="input-group-text"> $</div>
											 </div>
														<input type="text" class="form-control form-control-sm text-right"  readonly="1" name="total[]" > 
										</div>
									</td>
									<td>

										<a onclick=" $(this).parents('.clonedInput').remove(); calculateSum(); return false" href="javascript:void(0)" class="remove btn btn-xs btn-danger">-</a>
								 	
									</td>
								</tr>
								@endif

								
								<tr>
									<td colspan="5">
										  <a href="javascript:void(0);" class="addC btn btn-sm btn-primary" style="color: #fff !important;" rel=".clone"><i class="fa fa-plus"></i> New Item</a>
									</td>
									
								</tr>
								<tr>
									<td colspan="2"></td>
									<td>Sub Total</td>
									<td>
										<div class="input-group">
											<div class="input-group-prepend">
											 	<div class="input-group-text"> $</div>
											 </div>
													<input type="text" class="form-control form-control-sm text-right" name="subtotal"  />
										</div>			

									</td>
								</tr>	
								<tr>
									<td colspan="2"></td>
									<td>Tax</td>
									<td>
										<div class="input-group">
											<div class="input-group-prepend">
											 	<div class="input-group-text"> % </div>
											 </div>
											 <input type="text" class="form-control form-control-sm text-right" name="invtax" />
										</div>
									</td>
								</tr>
								<tr>
									<td colspan="2"></td>
									<td>Discount</td>
									<td>
										<div class="input-group">
											<div class="input-group-prepend">
											 	<div class="input-group-text"> $ </div>
											 </div>
											 <input type="text" class="form-control form-control-sm text-right" name="invdiscount"  />
										</div>	 

									</td>
								</tr>
								<tr>
									<td colspan="2"></td>
									<td>Grand Total</td>
									<td>
										<div class="input-group">
											<div class="input-group-prepend">
											 	<div class="input-group-text"> $</div>
											 </div>
											 <input type="text" class="form-control form-control-sm text-right" name="invtotal"  />
										</div>
									</td>
								</tr>
								
								<tr>
									<td colspan="4">
										<label> Client Note </label>
										<textarea type="text" class="form-control form-control-sm" name="note" >{{ $row['note'] }}</textarea>
									</td>
									
								</tr>
								<tr>
									<td colspan="4">
										<label> Terms & Conditions </label>
										<textarea type="text" class="form-control form-control-sm" name="terms" >{{ $row['terms'] }}</textarea>
									</td>
									
								</tr>
							</tbody>	

					</table>

			</div>

	</fieldset>

</div>		
{!! Form::close() !!}
</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
	.table-invoice tr td {
		border: none !important;
	}
	.table-invoice input.text-right {
		padding-right: 10px;
	}
</style>
			 
<script type="text/javascript">
$(document).ready(function() { 
	
	
		$("#project_id").jCombo("{!! url('sxinvoice/comboselect?filter=sx_projects:project_id:project_name') !!}",
		{  selected_value : '{{ $row["project_id"] }}' });
		
		$("#customer_id").jCombo("{!! url('sxinvoice/comboselect?filter=sx_customers:customer_id:name') !!}",
		{  selected_value : '{{ $row["customer_id"] }}' });
		 	
	 	 
	$('.addC').relCopy({});
	$("input[name*='qty'] , input[name*='amount'] , input[name='invdiscount'] , input[name='invtax']").addClass('calculate');
	calculateSum();
	$(".calculate").keyup(function(){ calculateSum();})

	$('.editor').summernote();
	
	$('.tips').tooltip();	
	$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
	$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 		
		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxinvoice/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});
				
	var form = $('#sxinvoiceFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  showRequest,
				success:       showResponse  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});

});

function showRequest()
{
		
}  
function showResponse(data)  {		
	
	if(data.status == 'success')
	{
		ajaxViewClose('#{{ $pageModule }}');
		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data');
		notyMessage(data.message);	
		$('#sximo-modal').modal('hide');	
	} else {
		notyMessageError(data.message);	
		return false;
	}	
}			 
function calculateSum()
{
	var Subtotal = 0;
	$('table tr.clone ').each(function(i){
		var Qty = $(this).find(" input[name*='qty']").val();
		var Price = $(this).find("input[name*='amount']").val();
		var sum = Qty * Price ;
		//alert( Qty +' + '+ Price + ' = '+ sum);
		Subtotal += sum;
	   $(this).find("input[name*='total']").val(sum);
	})

	$('input[name=subtotal]').val(Subtotal); 

	var Discount 	= $('input[name=invdiscount]').val(); 
	var Tax 		= $('input[name=invtax]').val(); 

	var Total =  ( Subtotal - Discount ) -  Tax  ;
	$('input[name=invtotal]').val(Total);
	$('#invtotalshow').html(Total)
	

}

</script>		 