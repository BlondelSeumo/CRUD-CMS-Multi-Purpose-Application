<?php usort($tableGrid, "SiteHelpers::_sort"); ?>

	 {!! (isset($search_map) ? $search_map : '') !!}
	 	@include($pageModule.'/toolbar')
	 <?php echo Form::open(array('url'=>'sxinvoice', 'class'=>'form-horizontal' ,'id' =>'SximoTable'  ,'data-parsley-validate'=>'' )) ;?>
	
	<div class="card"> 	
		<table class="table table-striped">
 				<thead>
 					<tr>
 						<th colspan="7"> All Invoice(s) </th>
 					</tr>
 				</thead>
 				<tbody>
 				<?php foreach ($rowData as $row) : ?>
 					<tr>
 						<td width="30"><input type="checkbox" class="ids minimal-green" name="ids[]" value="<?php echo $row->invoice_id ;?>" /></td>
 						<td><a href="{{ url('sxinvoice/'.$row->invoice_id) }}" onclick="ajaxViewDetail('#{{ $pageModule }}',this.href); return false;"> INV-{{ $row->number }} </a></td>
 						<td> $ {{ number_format($row->total,0) }} </td>
 						<td style="font-size: 9px">
 							Progress : 
 							<div class="progress progress-sm mb-2">
							  <div class="progress-bar bg-success" role="progressbar" style="width:25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
							</div>
							<p> $ {{ number_format($row->paid,0) }} of  $ {{ number_format($row->total,0) }}</p>

 						 </td>
 						<td style="font-size: 9px">
 							Date : {{ $row->date }}<br />
 							Due Date : {{ $row->duedate }}
 						</td>
 						<td>
 							{{ $row->project_name }} <br />
 							<small> {{ $row->name }} </small>
 						</td>
 						
 						<td>
 							<label class="badge badge-danger">{{ $row->status }}</label>
 						</td>

 					</tr>


 				<?php endforeach;?>

           	</tbody>


		</table> 	
	
	</div>	
	
	<input type="hidden" name="action_task" value="" />
	<?php echo Form::close() ;?>
	@include('ajaxfooter')


@if($setting['inline'] =='true') @include('sximo.module.utility.inlinegrid') @endif
@include('sximo.module.template.ajax.javascript')
<style type="text/css">
	.progress {
		height: 7px;
	}
</style>