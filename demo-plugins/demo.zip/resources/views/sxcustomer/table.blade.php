<?php usort($tableGrid, "SiteHelpers::_sort"); ?>

	 {!! (isset($search_map) ? $search_map : '') !!}
	 	@include($pageModule.'/toolbar')
	 <?php echo Form::open(array('url'=>'sxcustomer', 'class'=>'form-horizontal' ,'id' =>'SximoTable'  ,'data-parsley-validate'=>'' )) ;?>
<div class="table-container" >	

	<div class="card">

			<table class="table">
				<tbody>
				@foreach ($rowData as $row) 
					<tr>
						<td> <input type="checkbox" class="ids minimal-green" name="ids[]" value="<?php echo $row->customer_id ;?>" />	</td>
						<td>
							{!! SiteHelpers::showUploadedFile($row->logo,'/uploads/crm/customers/',40 ) !!}
							
						</td>
						<td 
							style="  cursor: pointer;" 
						 onclick="SximoModal('{{ url('sxcustomer/'.$row->customer_id.'/edit') }}','Edit Customer'); return false ; ">
							
							<b> {{ $row->name }} </b>
							<p>
								{{ $row->contact }} 
							</p>

						</td>
						
						<td>
							<p>
								Email : {{ $row->email }}  <br />
								Phone : {{ $row->phone }} 
							</p>

						</td>
						<td>	
							<p>
								{{ $row->address1 }} {{ $row->address2 }}  <br />
								{{ $row->city }} - {{ $row->state }}  - {{ $row->country }} 
							</p>

						</td>
						<td> 
							<span class="tips" title="{{ $row->fullname }}" >
							{!! SiteHelpers::showUploadedFile($row->avatar,'/uploads/users/',40 ) !!}
								</span>
						</td>

					</tr>
				@endforeach
				</tbody>

			</table>
	</div>		
	
	
	</div>
	<input type="hidden" name="action_task" value="" />
	<?php echo Form::close() ;?>
	@include('ajaxfooter')
</div>	
<style type="text/css">
	.img-circle {
		border-radius: 50%;
	}
</style>
@if($setting['inline'] =='true') @include('sximo.module.utility.inlinegrid') @endif
@include('sximo.module.template.ajax.javascript')
