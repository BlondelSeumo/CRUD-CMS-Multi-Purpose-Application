<div class="form-ajax-box">
{!! Form::open(array('url'=>'sxcustomer?return='.$return, 'class'=>'form-vertical validated','files' => true , 'parsley-validate'=>'','novalidate'=>' ','id'=> 'sxcustomerFormAjax')) !!}

		
		<div class="p-5">

	
	<ul class="nav nav-tabs form-tab
	"><li class=" nav-item "><a href="#BasicInformation" data-toggle="tab" class="nav-link active">Basic Information</a></li>
				<li class=" nav-item "><a href="#Address" data-toggle="tab" class="nav-link ">Address</a></li>
				</ul><div class="tab-content"><div class="tab-pane m-t active" id="BasicInformation"> 
				{!! Form::hidden('customer_id', $row['customer_id']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Company Name    </label>									
										  <input  type='text' name='name' id='name' value='{{ $row['name'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 		
									  <div class="row">
									  		<div class="col-md-6">				
												  <div class="form-group  " >
													<label for="ipt" class=" control-label "> Contact Name    </label>									
													  <input  type='text' name='contact' id='contact' value='{{ $row['contact'] }}' 
									     class='form-control form-control-sm ' /> 						
												  </div> 		
											</div>
											<div class="col-md-6">	
												<div class="form-group  " >
										<label for="ipt" class=" control-label "> User Id    </label>									
										  <select name='user_id' rows='5' id='user_id' class='select2 '   ></select> 						
									  </div> 

											</div>
										</div>	
											

									  	<div class="row">
									  		<div class="col-md-6">		
												  <div class="form-group  " >
													<label for="ipt" class=" control-label "> Email    </label>									
													  <input  type='text' name='email' id='email' value='{{ $row['email'] }}' 
									     class='form-control form-control-sm ' /> 						
												  </div> 			
											</div>  	
										<div class="col-md-6">			
											  <div class="form-group  " >
												<label for="ipt" class=" control-label "> Phone    </label>									
												  <input  type='text' name='phone' id='phone' value='{{ $row['phone'] }}' 
								     class='form-control form-control-sm ' /> 						
											  </div> 	
											</div>
										</div>
											  				
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Logo    </label>									
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="logo" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="logo-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["logo"],"/uploads/crm/customers/") !!}
						</div>

						
					 						
									  </div> 	
									  <div class="form-group  " >
											<button type="submit" class="btn btn-primary btn-block  " name="apply"><i class="fa  fa-check"></i>  {{ Lang::get('core.sb_save') }} </button> 						
											
										</div>

									  						
									  
				</div>
				
				<div class="tab-pane m-t " id="Address"> 
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Address1    </label>									
										  <input  type='text' name='address1' id='address1' value='{{ $row['address1'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Address2    </label>									
										  <input  type='text' name='address2' id='address2' value='{{ $row['address2'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> City    </label>									
										  <input  type='text' name='city' id='city' value='{{ $row['city'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> State    </label>									
										  <input  type='text' name='state' id='state' value='{{ $row['state'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Zipcode    </label>									
										  <input  type='text' name='zipcode' id='zipcode' value='{{ $row['zipcode'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> Country    </label>									
										  <input  type='text' name='country' id='country' value='{{ $row['country'] }}' 
						     class='form-control form-control-sm ' /> 						
									  </div> 

									  <div class="form-group  " >
											<button type="submit" class="btn btn-primary btn-block  " name="apply"><i class="fa  fa-check"></i>  {{ Lang::get('core.sb_save') }} </button> 						
											
										</div>
				</div>
				
													
						<input type="hidden" name="action_task" value="save" />
				


	

</div>		
{!! Form::close() !!}
</div>

<style type="text/css">
	.modal-body .form-ajax-box {
		margin: -15px;
	}
</style>
			 
<script type="text/javascript">
$(document).ready(function() { 
	
	$("#user_id").jCombo("{!! url('sxcustomer/comboselect?filter=tb_users:id:first_name|last_name|email') !!}",
		{  selected_value : '{{ $row["user_id"] }}' });
	
	$('.editor').summernote();
	
	$('.tips').tooltip();	
	$(".select2").select2({ width:"98%"});	
	$('.date').datepicker({format:'yyyy-mm-dd',autoClose:true})
	$('.datetime').datetimepicker({format: 'yyyy-mm-dd hh:ii:ss'}); 		
		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("sxcustomer/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});
				
	var form = $('#sxcustomerFormAjax'); 
	form.parsley();
	form.submit(function(){
		
		if(form.parsley().isValid()){			
			var options = { 
				dataType:      'json', 
				beforeSubmit :  showRequest,
				success:       showResponse  
			}  
			$(this).ajaxSubmit(options); 
			return false;
						
		} else {
			return false;
		}		
	
	});
	$('.form-tab a').on('click', function (e) {
	  	e.preventDefault()
	  	$(this).tab('show')
	})

});

function showRequest()
{
		
}  
function showResponse(data)  {		
	
	if(data.status == 'success')
	{
		ajaxViewClose('#{{ $pageModule }}');
		ajaxFilter('#{{ $pageModule }}','{{ $pageUrl }}/data');
		notyMessage(data.message);	
		$('#sximo-modal').modal('hide');	
	} else {
		notyMessageError(data.message);	
		return false;
	}	
}			 

</script>		 