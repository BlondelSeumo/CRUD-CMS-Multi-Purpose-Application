

		 {!! Form::open(array('url'=>'aproduct/savepublic', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Products ( AJax )</legend>
				{!! Form::hidden('productId', $row['productId']) !!}					
									  <div class="form-group row  " >
										<label for="Code" class=" control-label col-md-4 text-left"> Code <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='productCode' id='productCode' value='{{ $row['productCode'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Name" class=" control-label col-md-4 text-left"> Name <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='productName' id='productName' value='{{ $row['productName'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="ProductLine" class=" control-label col-md-4 text-left"> ProductLine </label>
										<div class="col-md-8">
										  <input  type='text' name='productLine' id='productLine' value='{{ $row['productLine'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Scale" class=" control-label col-md-4 text-left"> Scale <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='productScale' id='productScale' value='{{ $row['productScale'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Vendor" class=" control-label col-md-4 text-left"> Vendor <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='productVendor' id='productVendor' value='{{ $row['productVendor'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Description" class=" control-label col-md-4 text-left"> Description </label>
										<div class="col-md-8">
										  <textarea name='productDescription' rows='5' id='productDescription' class='form-control form-control-sm '  
				           >{{ $row['productDescription'] }}</textarea> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Quantity" class=" control-label col-md-4 text-left"> Quantity <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='quantityInStock' id='quantityInStock' value='{{ $row['quantityInStock'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="Price" class=" control-label col-md-4 text-left"> Price <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='buyPrice' id='buyPrice' value='{{ $row['buyPrice'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> 					
									  <div class="form-group row  " >
										<label for="MSRP" class=" control-label col-md-4 text-left"> MSRP <span class="asterix"> * </span></label>
										<div class="col-md-8">
										  <input  type='text' name='MSRP' id='MSRP' value='{{ $row['MSRP'] }}' 
						required     class='form-control form-control-sm ' /> 
										 </div> 
										 
									  </div> </fieldset></div>

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
