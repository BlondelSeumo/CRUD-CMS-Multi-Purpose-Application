<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxpayment extends Sximo  {
	
	protected $table = 'sx_payments';
	protected $primaryKey = 'payment_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT sx_payments.* FROM sx_payments  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sx_payments.payment_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
