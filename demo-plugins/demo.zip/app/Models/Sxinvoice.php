<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxinvoice extends Sximo  {
	
	protected $table = 'sx_invoices';
	protected $primaryKey = 'invoice_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  
			SELECT 
				sx_invoices.* , project_name ,  name  ,
				SUM(sx_payments.`amount`) AS paid

			FROM sx_invoices
			LEFT JOIN sx_projects ON sx_projects.project_id = sx_invoices.project_id 
			LEFT JOIN sx_customers ON sx_customers.customer_id = sx_invoices.customer_id 
			LEFT JOIN sx_payments ON sx_payments.invoice_id = sx_invoices.invoice_id 

		 ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sx_invoices.invoice_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return " GROUP BY sx_invoices.invoice_id ";
	}
	
	public static function items( $invoice_id ){
		return \DB::table('sx_invoice_items')->where('invoice_id', $invoice_id)->get();
	}

}
