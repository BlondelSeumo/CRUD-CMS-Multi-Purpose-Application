<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxitem extends Sximo  {
	
	protected $table = 'sx_invoice_items';
	protected $primaryKey = 'item_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT sx_invoice_items.* FROM sx_invoice_items  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sx_invoice_items.item_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
