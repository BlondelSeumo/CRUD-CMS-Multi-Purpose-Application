<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxissue extends Sximo  {
	
	protected $table = 'sx_issues';
	protected $primaryKey = 'issue_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT 
	sx_issues.* ,
	first_name , avatar , email
 
 FROM sx_issues 
 LEFT JOIN tb_users ON tb_users.id = sx_issues.user_id ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE sx_issues.issue_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
