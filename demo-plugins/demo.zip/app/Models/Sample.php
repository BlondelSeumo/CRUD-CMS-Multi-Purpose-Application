<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sample extends Sximo  {
	
	protected $table = 'sample';
	protected $primaryKey = 'employeeNumber';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT sample.* FROM sample  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sample.employeeNumber IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
