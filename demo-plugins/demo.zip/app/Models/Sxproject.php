<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxproject extends Sximo  {
	
	protected $table = 'sx_projects';
	protected $primaryKey = 'project_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT 
	sx_projects.* ,sx_customers.name , logo , team_name , user_ids
 FROM sx_projects 
 LEFT JOIN sx_customers ON sx_customers.customer_id = sx_projects.customer_id
 LEFT JOIN sx_teams ON sx_teams.team_id = sx_projects.team_id ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE sx_projects.project_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

	static function countSecTaskCheck( $project_id ) {

		$data = [
			'milestone'	=> 0 ,
			'tasks'	=> 0 ,
			'todo'	=> 0 
		];
		$rows = \DB::select("
			SELECT 
				COUNT( DISTINCT(sx_task_sections.section_id)) AS milestone ,
				COUNT( DISTINCT(sx_tasks.task_id)) AS tasks ,
				COUNT(DISTINCT(sx_task_todo.todo_id)) AS todo 
			FROM sx_task_sections 
			LEFT JOIN sx_tasks ON sx_tasks.section_id = sx_task_sections.section_id
			LEFT JOIN sx_task_todo ON sx_task_todo.task_id = sx_tasks.task_id
			WHERE sx_task_sections.project_id = '{$project_id}'
			GROUP  BY sx_task_sections.project_id 
		");
		if(count($rows) >=1) {
			$data =  (array) $rows[0];

		} 
		return $data ;
	}

	

}
