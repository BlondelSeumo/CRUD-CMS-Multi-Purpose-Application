<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxticket extends Sximo  {
	
	protected $table = 'sx_tickets';
	protected $primaryKey = 'ticke_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT 
	sx_tickets.* , username , avatar , email
 FROM sx_tickets  
LEFT JOIN tb_users ON tb_users.id = sx_tickets.user_id ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE sx_tickets.ticke_id IS NOT NULL AND parent_id IS NULL  AND entry_by IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	
	public static function getReply( $parentid ){
		$rows = \DB::table('sx_tickets')
				->select('sx_tickets.*','username','email','avatar')
				->leftJoin('tb_users', 'tb_users.id', '=', 'sx_tickets.user_id')
		->where('parent_id',$parentid)->orderBy('createdOn','Asc')->get();
		return $rows ;
	}
	public static function delete_reply( $id , $parentid ){
		$rows = \DB::table('sx_tickets')
				->where('parent_id',$parentid)
				->where('ticke_id', $id )
				->where('user_id' , Session('uid'))
				->delete();
	}

	public static function selectTeam() {
		if(!\Schema::hasTable('sx_teams')){
			return [] ;
		} else {

			return \DB::table('sx_teams')->get();

		}
	}
}
