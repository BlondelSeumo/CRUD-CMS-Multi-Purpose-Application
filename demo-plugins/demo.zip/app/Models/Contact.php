<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class contact extends Sximo  {
	
	protected $table = 'contacts';
	protected $primaryKey = 'contact_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT contacts.* FROM contacts ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE contacts.contact_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
