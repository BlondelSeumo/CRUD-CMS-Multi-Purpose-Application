<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxcustomer extends Sximo  {
	
	protected $table = 'sx_customers';
	protected $primaryKey = 'customer_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  
 SELECT sx_customers.* , CONCAT(first_name,' ',last_name) AS fullname , avatar
 FROM sx_customers 
 LEFT JOIN tb_users ON tb_users.id = sx_customers.user_id

		 ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sx_customers.customer_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
