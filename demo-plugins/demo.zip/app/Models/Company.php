<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class company extends Sximo  {
	
	protected $table = 'companies';
	protected $primaryKey = 'comp_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT companies.* FROM companies ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE companies.comp_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
