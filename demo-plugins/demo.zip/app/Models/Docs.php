<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class docs extends Sximo  {
	
	protected $table = 'documentations';
	protected $primaryKey = 'doc_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT documentations.* FROM documentations  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE documentations.doc_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	
	public static function getLists()
	{
		$parents = \DB::table('documentations')->where('parent_id',0)->get();
		$rows = [] ;
		foreach($parents as $row) {

			$childs = \DB::table('documentations')->where('parent_id', $row->doc_id )->get();
			$rows[] = [
				'row'		=> $row ,
				'childs'	=> $childs 
			];

		}
		return $rows ;
	}

	public static function getCompleteDocs( $alias )
	{
		$row = \DB::table('documentations')->where('alias', $alias)->orWhere('doc_id', $alias )->get();
		$rows = $row[0] ;		
		
		return $rows ;
	}	
	public static function getCompleteArticles( $parent_id   )
	{
		$data = [] ;
		$rows = \DB::table('documentations')->where('parent_id', $parent_id)->get();
		foreach($rows as $row) {
			$childs = \DB::table('documentations')->where('parent_id', $row->doc_id )->get();
			$data[] = [
				'rows' 		=> $row,
				'childs'	=> $childs
			];
		}
		return $data ;
	}
	public static function readArticle( $id )
	{
		$row = \DB::table('documentations')->where('doc_id', $id)->get();
		$rows = $row[0] ;		
		
		return $rows ;
	}	
}
