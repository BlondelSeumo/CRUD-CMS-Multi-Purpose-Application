<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxteam extends Sximo  {
	
	protected $table = 'sx_teams';
	protected $primaryKey = 'team_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT sx_teams.* FROM sx_teams  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE sx_teams.team_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}


	static public function teamAvatar( $ids = array()   )
	{
		$ids = explode(",",$ids);
		$data = [] ;
		$rows = \DB::table('tb_users')->whereIn('id',$ids)->get();
		foreach( $rows as $row ){
			if(file_exists("./uploads/users/".$row->avatar) && $row->avatar !="") {
				$data[] = [
					'id'	=> $row->id ,
					'name'	=> $row->first_name .' '. $row->last_name ,
					'email'	=> $row->email ,
					'avatar'	=>  $row->avatar
				];	
			} 
			else {
				$data[] = [
					'id'	=> $row->id ,
					'name'	=> $row->first_name .' '. $row->last_name ,
					'email'	=> $row->email ,
					'avatar'	=> "avatar.png"
				];

			}	 
		}
		return $data ;
	}
	

}
