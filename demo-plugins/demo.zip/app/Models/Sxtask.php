<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class sxtask extends Sximo  {
	
	protected $table = 'sx_tasks';
	protected $primaryKey = 'task_id';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return " SELECT 
	sx_tasks.* , CONCAT(first_name,' ' ,last_name) AS fullname  , section_name ,project_name
FROM sx_tasks 
LEFT JOIN tb_users ON tb_users.id = sx_tasks.assigned_to
LEFT JOIN sx_task_sections ON sx_task_sections.section_id = sx_tasks.section_id
LEFT JOIN sx_projects ON sx_projects.project_id = sx_tasks.project_id ";
	}	

	public static function queryWhere(  ){
		
		return " WHERE sx_tasks.task_id IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}

	public static function getCompleteTasks( $projectid = 0 ) {

		$data = [] ;
		if($projectid == 0) {
			$sections = \DB::table('sx_task_sections')
						->select('sx_task_sections.*','project_name')
						->leftJoin('sx_projects', 'sx_projects.project_id', '=', 'sx_task_sections.project_id')
						->get();
		}
		else {
			$sections = \DB::table('sx_task_sections')
						->select('sx_task_sections.*','project_name')
						->leftJoin('sx_projects', 'sx_projects.project_id', '=', 'sx_task_sections.project_id')
						->where('sx_task_sections.project_id', $projectid)
						->get();
		}		
		foreach($sections as $section) {
			$tasks = \DB::select("
					SELECT 
						sx_tasks.* , CONCAT(first_name,' ' ,last_name) AS fullname , avatar ,
						COUNT(sx_task_todo.todo_id) AS todo ,
						SUM(CASE WHEN  sx_task_todo.status ='1' THEN 1 ELSE 0 END ) AS finished ,
						( SUM(CASE WHEN  sx_task_todo.status ='1' THEN 1 ELSE 0 END ) / COUNT(sx_task_todo.todo_id) * 100 ) AS progress
					FROM sx_tasks 
					LEFT JOIN tb_users ON tb_users.id = sx_tasks.assigned_to
					LEFT JOIN sx_task_todo ON sx_task_todo.task_id = sx_tasks.task_id
					WHERE section_id = '{$section->section_id}'
					GROUP BY sx_tasks.task_id ORDER BY start_date ASC

				");

			$data[] = [
				'section'	=> $section ,
				'tasks'		=> $tasks 
			];

		}
		return $data ;



	}
	public static function getSectionDetail( $id ) {
		$data = \DB::table('sx_task_sections')->where('section_id', $id )->get();
		if( count($data) >=1 ) {
			$data = (array) $data[0];
		}
		else {
			$data = self::getColumnTable( 'sx_task_sections');
		}
		return $data ;

	}
	public static function getTasksToDo( $id ) {
		$data = \DB::table('sx_task_todo')->where('task_id', $id )->get();
		return $data ;

	}	
	public static function getTasksComments( $id ) {
		$data = \DB::table('sx_task_comments')->where('task_id', $id )->get();
		return $data ;

	}		
	public static function selectProject() {
		if(!\Schema::hasTable('sx_projects')){
			return [] ;
		} else {

			return \DB::table('sx_projects')->get();

		}
	}	
	public static function re_assigned( $task_id , $uid ) {
		\DB::table('sx_tasks')->where('task_id', $task_id )->update(['assigned_to' => $uid ] );

	}		
	public static function re_status( $task_id , $uid ) {
		\DB::table('sx_tasks')->where('task_id', $task_id )->update(['task_status' => $uid ] );

	}
}
