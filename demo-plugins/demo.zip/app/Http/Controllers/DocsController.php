<?php namespace App\Http\Controllers;

use App\Models\Docs;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator as Paginator;
use Validator, Input, Redirect ; 


class DocsController extends Controller {

	protected $layout = "layouts.main";
	protected $data = array();	
	public $module = 'docs';
	static $per_page	= '50';

	public function __construct()
	{		
		parent::__construct();
		$this->model = new Docs();	
		
		$this->info = $this->model->makeInfo( $this->module);	
		$this->data = array(
			'pageTitle'	=> 	$this->info['title'],
			'pageNote'	=>  $this->info['note'],
			'pageModule'=> 'docs',
			'return'	=> self::returnUrl()
			
		);
		$this->access = $this->access($this->info['id']  , session('gid') );
		
	}

	public function index( Request $request )
	{
		// Make Sure users Logged 
		if(!\Auth::check()) 
			return redirect('user/login')->with('status', 'error')->with('message','You are not login');

		$this->access = $this->access($this->info['id']  );
		$this->data['rowData'] = $this->model->getLists();
		$this->data['access']	= $this->access ;
		if($this->access['is_view'] ==0) 
			return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');				
		// Render into template
		return view( $this->module.'.index',$this->data);
	}	

	function create( Request $request , $id =0 ) 
	{
		$this->hook( $request  );
		if($this->access['is_add'] ==0) 
			return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');

		$this->data['row'] = $this->model->getColumnTable( $this->info['table']); 
		$this->data['parents'] = $this->model->getCompleteArticles( $request->get('parent') ); 	
		$this->data['id'] = '';
		$this->data['return'] = $request->get('return');
		$this->data['parent'] = $request->get('parent');
		return view($this->module.'.form',$this->data);
	}
	function edit( Request $request , $id ) 
	{
		$this->hook( $request , $id );

		if(!isset($this->data['row']))
			return redirect($this->module)->with('message','Record Not Found !')->with('status','error');

		if($this->access['is_edit'] ==0 )
			return redirect('dashboard')->with('message',__('core.note_restric'))->with('status','error');

		$this->data['row'] = (array) $this->data['row'];	
		$this->data['parents'] = $this->model->getCompleteArticles( $request->get('parent') ); 		
		$this->data['id'] = $id;
		$this->data['return'] = $request->get('return');
		$this->data['parent'] = $request->get('parent');
		return view($this->module.'.form',$this->data);
	}	
	function show( Request $request , $id ) 
	{
		/* Handle import , export and view */
		$task =$id ;
		switch( $task)
		{
			case 'search':
				return $this->getSearch();
				break;
			case 'lookup':
				return $this->getLookup($request );
				break;
			case 'comboselect':
				return $this->getComboselect( $request );
				break;
			case 'import':
				return $this->getImport( $request );
				break;
			case 'export':
				return $this->getExport( $request );
				break;
			case 'delete':
				return $this->destroy( $request );
				break;	
			default:

				$this->data['data'] = (array) $this->model->getCompleteDocs( $id );
				$this->data['row'] =  $this->data['data'] ;
				$this->data['articles'] = $this->model->getCompleteArticles( $this->data['data']['doc_id'] );

				if($request->has('article')) {
					$this->data['row'] =(array) $this->model->readArticle( $request->get('article') );
				}
				$this->data['access'] = $this->access($this->info['id']  , session('gid') );
				
			

				return view($this->module.'.view',$this->data);	
				break;		
		}
	}
	function store( Request $request  )
	{
		$task = $request->input('action_task');
		switch ($task)
		{
			default:
				$rules = $this->validateForm();
				$validator = Validator::make($request->all(), $rules);
				if ($validator->passes()) 
				{
					$data 		= $this->validatePost( $request );
					$data['alias'] = \SiteHelpers::seourl( $request->input('title') );
					$id = $this->model->insertRow($data , $request->input( $this->info['key']));
					
					/* Insert logs */
					$this->model->logs($request , $id);
					if($request->has('apply'))
						return redirect( $this->module .'/'.$request->get('return').'?article='.$id )->with('message',__('core.note_success'))->with('status','success');

					if($request->input('parent_id') <= 0 )
						return redirect( $this->module  )->with('message',__('core.note_success'))->with('status','success');

					return redirect( $this->module .'/'.$request->get('return'). '?article='.$id )->with('message',__('core.note_success'))->with('status','success');
				} 
				else {
					return redirect( $this->module .'/'.$request->get('return').'?article='.$id)
							->with('message',__('core.note_error'))->with('status','error')
							->withErrors($validator)->withInput();

				}
				break;
			case 'public':
				return $this->store_public( $request );
				break;

			case 'delete':
				$result = $this->destroy( $request );
				return redirect($this->module.'?'.$this->returnUrl())->with($result);
				break;

			case 'import':
				return $this->PostImport( $request );
				break;

			case 'copy':
				$result = $this->copy( $request );
				return redirect($this->module.'?'.$this->returnUrl())->with($result);
				break;		
		}	
	
	}	

	public function destroy( $request)
	{
		// Make Sure users Logged 
		if(!\Auth::check()) 
			return redirect('user/login')->with('status', 'error')->with('message','You are not login');

		$this->access = $this->model->validAccess($this->info['id'] , session('gid'));
		if($this->access['is_remove'] ==0) 
			return redirect('dashboard')
				->with('message', __('core.note_restric'))->with('status','error');
		// delete multipe rows 
		if(!is_null($request->get('id')) >=1)
		{
			$this->model->destroy($request->get('id'));
			return redirect($this->module.'/'.$request->get('return'))->with( ['message'=>__('core.note_success_delete'),'status'=>'success']);
		} else {	
			return redirect($this->module.'/'.$request->get('return'))->with( ['message'=>__('core.Deleted'),'status'=>'error']);			
		}
	}	
	
	public static function documentation( $id , $type = 'default' )
	{

		$mode  = isset($_GET['article']) ? 'view' : 'default' ;
		$row = (array) Docs::getCompleteDocs( $id );
		$data = array(
			'pageTitle'	=> 	$row['title'],
			'pageNote'	=>  'Documentation Online',
			'data'		=> $row 		
		);	


		$data['row'] =  $row  ;
		$data['mode']	= $mode ;
		$data['articles'] = Docs::getCompleteArticles( $data['data']['doc_id'] );

		if($mode == 'view')
		{
			$data['row'] = (array) Docs::readArticle( $_GET['article']);
			$data['related'] = Docs::getCompleteArticles( $data['row']['parent_id'] );		
		} 
		//echo '<pre>'; print_r($data['related']); echo '</pre>'; exit;
		if($type =='faq') {
			// FAQ mode
			return view('docs.public.faq',$data);
		} elseif( $type =='kb') {
			// Knowledge mode
			return view('docs.public.kb',$data);

		} else {
			return view('docs.public.single',$data);
		}
		return view('docs.public.single',$data);

	}
	public static function knowledgebase()
	{
		$mode  = isset($_GET['article']) ? 'view' : 'default' ;
		$model  = new Docs();
		$info = $model::makeInfo('docs');
		$data = array(
			'pageTitle'	=> 	$info['title'],
			'pageNote'	=>  $info['note']			
		);	

		if($mode == 'view')
		{
			$id = $_GET['view'];
			$row = $model::getRow($id);
			if($row)
			{
				$data['row'] =  $row;
				$data['fields'] 		=  \SiteHelpers::fieldLang($info['config']['grid']);
				$data['id'] = $id;
				return view('docs.public.view',$data);			
			}			
		} 
		else {
			$data['rowData'] = Docs::getLists();
			return view('docs.public.index',$data);	
		}

	}

	public static function display(  )
	{
		$mode  = isset($_GET['view']) ? 'view' : 'default' ;
		$model  = new Docs();
		$info = $model::makeInfo('docs');
		$data = array(
			'pageTitle'	=> 	$info['title'],
			'pageNote'	=>  $info['note']			
		);	
		if($mode == 'view')
		{
			$id = $_GET['view'];
			$row = $model::getRow($id);
			if($row)
			{
				$data['row'] =  $row;
				$data['fields'] 		=  \SiteHelpers::fieldLang($info['config']['grid']);
				$data['id'] = $id;
				return view('docs.public.view',$data);			
			}			
		} 
		else {
			$data['rowData'] = Docs::getLists();
			return view('docs.public.index',$data);	
		}

	}
	function store_public( $request)
	{
		
		$rules = $this->validateForm();
		$validator = Validator::make($request->all(), $rules);	
		if ($validator->passes()) {
			$data = $this->validatePost(  $request );		
			 $this->model->insertRow($data , $request->input('id'));
			return  Redirect::back()->with('message',__('core.note_success'))->with('status','success');
		} else {

			return  Redirect::back()->with('message',__('core.note_error'))->with('status','error')
			->withErrors($validator)->withInput();

		}	
	
	}
}
