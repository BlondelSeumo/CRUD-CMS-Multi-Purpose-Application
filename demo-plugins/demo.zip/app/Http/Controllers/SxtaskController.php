<?php namespace App\Http\Controllers;

use App\Models\Sxtask;
use App\Models\Sxteam;
use App\Models\Sxproject;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator as Paginator;
use Validator, Input, Redirect ; 

class SxtaskController extends Controller {

	protected $layout = "layouts.main";
	protected $data = array();	
	public $module = 'sxtask';
	static $per_page	= '50';
	
	public function __construct() 
	{
		parent::__construct();
		$this->model = new Sxtask();
		
		$this->info = $this->model->makeInfo( $this->module);
		$this->access = array();
	
		$this->data = array(
			'pageTitle'			=> 	$this->info['title'],
			'pageNote'			=>  $this->info['note'],
			'pageModule'		=> 'sxtask',
			'pageUrl'			=>  url('sxtask'),
			'return' 			=> 	self::returnUrl()	
		);		
				
	} 
	
	public function index( Request $request  )
	{
		if(!\Auth::check()) 
			return redirect('user/login')->with('msgstatus', 'error')->with('messagetext','You are not login');

		$this->access = $this->model->validAccess($this->info['id'] , session('gid'));
		if($this->access['is_view'] ==0) 
			return redirect('dashboard')->with('messagetext',\Lang::get('core.note_restric'))->with('msgstatus','error');
				
		$this->data['access']		= $this->access;
		$this->data['project']		= ($request->has('p') ? $request->get('p') : '' );
		$this->data['view_type']		= ($request->has('view') ? $request->get('view') : 'list' );	


		return view($this->module.'.index',$this->data);
	}
	function create( Request $request ) 
	{
		$id = 0;
		$this->hook( $request  );
		if($this->access['is_add'] ==0) 
			return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');

		$this->data['row'] = $this->model->getColumnTable( $this->info['table']); 
		
		$this->data['id'] = '';
		$this->data['setting'] 		= $this->info['setting']; 
		$this->data['filter'] = $request->get('p') ;
		$project = Sxproject::getRow($request->get('p')) ;
		$this->data['teams'] = Sxteam::teamAvatar( $project->user_ids );
		//print_r($this->data);exit;

		$this->data['section_id'] = $request->get('section_id') ;


		return view($this->module.'.form',$this->data);
	}		
	function edit( Request $request , $id ) 
	{
		$this->hook( $request , $id );
		if(!isset($this->data['row']))
			return redirect($this->module)->with('message','Record Not Found !')->with('status','error');
		if($this->access['is_edit'] ==0 )
			return redirect('dashboard')->with('message',__('core.note_restric'))->with('status','error');

		$this->data['row'] = (array) $this->data['row'];
		
		$this->data['id'] = $id;

		return view($this->module.'.form',$this->data);
	}
	function show( Request $request , $id ) 
	{
		/* Handle import , export and view */
		$task =$id ;
		switch( $task)
		{
			case 'data':
			//	$this->grab( $request) ;
				$this->data['access'] = $this->access( $this->info['id'] , Session('gid'));
				$this->data['tasks'] = Sxtask::getCompleteTasks( $request->get('p')) ;
				$this->data['projects'] = Sxtask::selectProject() ;
				$this->data['filter'] = $request->get('p');

				$calendar = [] ;
				foreach($this->data['tasks'] as $cals) {
					foreach($cals['tasks'] as $task) {
						$calendar[] = [
							'id'	=> $task->task_id ,
							'project_id'	=> $cals['section']->project_id ,
							'title'	=> $task->task_name , 
							'start'	=> $task->start_date ,
							'end'	=> $task->end_date
 						];
					}	
				}
				$this->data['calendar'] = json_encode($calendar) ;
			//	print_r($calendar);

				$this->data['view_type']		= ($request->has('view') ? $request->get('view') : 'list' );	
				return view( $this->module.'.table',$this->data);
				break;
			case 'search':
				return $this->getSearch();	
				break;
							
			case 'lookup':
				return $this->getLookup($request );
				break;				

			case 'comboselect':
				return $this->getComboselect( $request );
				break;
			case 'import':
				return $this->getImport( $request );
				break;
			case 'export':
				return $this->getExport( $request );
				break;

			case 'section':
				$this->data['row'] = Sxtask::getSectionDetail( $request->get('id'));
				$this->data['filter'] = $request->get('p') ;
				$this->data['projects'] = Sxtask::selectProject() ;
				return view($this->module.'.section',$this->data);	
				break;
	

			case 'todo_ok':
				\DB::table('sx_task_todo')
				->where('todo_id', $request->get('id'))
				->where('user_id', Session('uid'))
				->update(['status' => '1']);

				//Sxtask::deleteDataRow('sx_task_todo','todo_id', explode(",", $request->get('todo_id')));
				//$this->data['todo'] = Sxtask::getTasksToDo( $request->get('id'));
				//return view($this->module.'.todo',$this->data);	
				break;

			case 'todo_cancel':
				\DB::table('sx_task_todo')
				->where('todo_id', $request->get('id'))
				->where('user_id', Session('uid'))
				->update(['status' => '0']);	
				break;

			case 'todo_delete':
				Sxtask::deleteDataRow('sx_task_todo','todo_id', explode(",", $request->get('todo_id')));
				$this->data['todo'] = Sxtask::getTasksToDo( $request->get('id'));
				return view($this->module.'.todo',$this->data);	
				break;

			case 'todo':
				$this->data['todo'] = Sxtask::getTasksToDo( $request->get('id'));
				return view($this->module.'.todo',$this->data);	
				break;

			case 're_assigned':
				Sxtask::re_assigned( $request->get('id'),  $request->get('u'));
				return response()->json(['message'=>'Task has been re-assigned','status'=>'success']);
				break;	

			case 're_status':
				Sxtask::re_status( $request->get('id'),  $request->get('u'));
				return response()->json(['message'=>'Task has been re-status','status'=>'success']);
				break;		

			case 'comment_delete':
				Sxtask::deleteDataRow('sx_task_comments','comment_id', explode(",", $request->get('comment_id')));
				$this->data['comments'] = Sxtask::getTasksComments( $request->get('id'));
				return view($this->module.'.comment',$this->data);	
				break;	

			case 'comment':
				$this->data['comments'] = Sxtask::getTasksComments( $request->get('id'));
				return view($this->module.'.comment',$this->data);	
				break;


			default:
				$this->hook( $request , $id );
				if(!isset($this->data['row']))
					return redirect($this->module)->with('message','Record Not Found !')->with('status','error');

				if($this->access['is_detail'] ==0) 
					return redirect('dashboard')->with('message', __('core.note_restric'))->with('status','error');
				$this->data['todo'] = Sxtask::getTasksToDo( $id );
				$this->data['filter'] = $request->get('p') ;
				$project = Sxproject::getRow($request->get('p')) ;
				$this->data['teams'] = Sxteam::teamAvatar( $project->user_ids );
				$this->data['option_status'] = [
					'not_started' ,'in_progress','review','completed'
				];

				return view($this->module.'.view',$this->data);	
				break;		
		}
	}	

	function store( Request $request  )
	{
		$task = $request->input('action_task');
		switch ($task)
		{
			default:
				$rules = $this->validateForm();
				$validator = Validator::make($request->all(), $rules);
				if ($validator->passes()) 
				{
					$data = $this->validatePost( $request );
					$id = $request->input( $this->info['key']);
					$id = $this->model->insertRow($data , $request->input( $this->info['key']));
					
					/* Insert logs */
					$this->model->logs($request , $id);
					
					return response()->json(array(
						'status'=>'success',
						'message'=> __('core.note_success')
						));	
					
				} else {

					$message = $this->validateListError(  $validator->getMessageBag()->toArray() );
					return response()->json(array(
						'message'	=> $message,
						'status'	=> 'error'
					));	
				}
				break;
			case 'delete':
				$result = $this->destroy( $request );
				return response()->json($result);
				break;

			case 'delete_section':
				//$result = $this->destroy( $request );
				Sxtask::deleteDataRow('sx_task_sections','section_id', array($request->input('id') 	));
				return response()->json(['message'=>'Section has been deleted','status'=>'success']);
				break;	

			case 'import':
				return $this->PostImport( $request );
				break;

			case 'copy':
				$result = $this->copy( $request );
				return response()->json($result);
				break;	

			case 'section':
				$data = [
					
					'project_id'	=> $request->input('project_id'),
					'section_name'	=> $request->input('section_name'),
					//'createdOn'	=> date("Y-m-d H:i:s")
				];
				Sxtask::updateDataRow('sx_task_sections','section_id',$data, $request->input('section_id'));
				return response()->json(['message'=>'Message has been posted','status'=>'success']);
				break;

			case 'todo':
				$data = [
					
					'task_id'	=> $request->input('task_id'),
					'todo_name'	=> $request->input('todo_name'),
					'status'	=> 0 ,
					'user_id'	=> Session('uid')
					//'createdOn'	=> date("Y-m-d H:i:s")
				];
				Sxtask::updateDataRow('sx_task_todo','todo_id',$data);
				return response()->json(['message'=>'Message has been posted','status'=>'success']);
				break;		

			case 'comment':
				$data = [
					'user_id'	=> Session('uid') ,
					'task_id'	=> $request->input('task_id'),
					'content'	=> $request->input('content'),
					'createdOn'	=> date("Y-m-d H:i:s")
				];
				Sxtask::updateDataRow('sx_task_comments','comment_id',$data);
				return response()->json(['message'=>'Message has been posted','status'=>'success']);
				break;		
		}	
	
	}	


	public function destroy( $request)
	{
		// Make Sure users Logged 
		if(!\Auth::check()) 
			return redirect('user/login')->with('status', 'error')->with('message','You are not login');

		$this->access = $this->model->validAccess($this->info['id'] , session('gid'));
		if($this->access['is_remove'] ==0) 
			return redirect('dashboard')
				->with('message', __('core.note_restric'))->with('status','error');
		// delete multipe rows 
		if(count($request->input('ids')) >=1)
		{
		//	$this->model->destroy($request->input('ids'));
		//	
			\SiteHelpers::auditTrail( $request , "ID : ".implode(",",$request->input('ids'))."  , Has Been Removed Successfull");
			// redirect
        	return ['message'=>__('core.note_success_delete'),'status'=>'success'];	
	
		} else {
			return ['message'=>__('No Item Deleted'),'status'=>'error'];				
		}

	}		

}